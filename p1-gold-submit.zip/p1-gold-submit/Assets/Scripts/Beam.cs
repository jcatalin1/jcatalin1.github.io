using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Beam : MonoBehaviour
{
    public float speed = 10f;
    public float damage = 1f;

    private Vector3 direction;
    public SpriteRenderer spriteRenderer;

    public Sprite upSprite;
    public Sprite downSprite;
    public Sprite leftSprite;
    public Sprite rightSprite;

    public GameObject colliderObject;

    public bool isWand = false; 

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();

        if (colliderObject != null)
        {
            BeamColliderHandler colliderHandler = colliderObject.GetComponent<BeamColliderHandler>();
            if (colliderHandler != null)
            {
                colliderHandler.Initialize(this);
            }
            else
            {
                Debug.LogError("Collider object is missing the BeamColliderHandler script.");
            }
        }
        else
        {
            Debug.LogError("Collider object is not assigned.");
        }
    }

    public void Initialize(Vector3 dir)
    {
        direction = dir;
        Destroy(gameObject, 3f);
        isWand = false; 

        if (direction == Vector3.up)
        {
            spriteRenderer.sprite = upSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 0);
        }
        else if (direction == Vector3.down)
        {
            spriteRenderer.sprite = downSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 180);
        }
        else if (direction == Vector3.left)
        {
            spriteRenderer.sprite = leftSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 90);
        }
        else if (direction == Vector3.right)
        {
            spriteRenderer.sprite = rightSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, -90);
        }
    }

    public void InitializeWand(Vector3 dir)
    {
        direction = dir;
        Destroy(gameObject, 3f);
        isWand = true; 

        if (direction == Vector3.up)
        {
            spriteRenderer.sprite = upSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 0);
        }
        else if (direction == Vector3.down)
        {
            spriteRenderer.sprite = downSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 180);
        }
        else if (direction == Vector3.left)
        {
            spriteRenderer.sprite = leftSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 90);
        }
        else if (direction == Vector3.right)
        {
            spriteRenderer.sprite = rightSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, -90);
        }
    }


    void Update()
    {
        transform.Translate(new Vector3(direction.x, direction.y, 0) * speed * Time.deltaTime);
    }

    public void HandleCollision(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            Debug.Log("Beam hit enemy");

            Enemy enemy = other.GetComponent<Enemy>();
            if (enemy != null)
            {
                if(isWand == false)
                {
                    Vector3 knockbackDirection = (other.transform.position - transform.position).normalized;
                    enemy.TakeDamage((int)damage, knockbackDirection);
                }
                else if(isWand == true)
                {
                    Debug.Log("wand Beam hit enemy");
                    Vector3 knockbackDirection = (other.transform.position - transform.position).normalized;
                    enemy.TakeDamageByWandBeam((int)damage, knockbackDirection);


                    //EnemyType enemyType = enemy.GetComponent<EnemyType>(); 
                    //if (enemy != null && enemyType != null)
                    //{
                    //    Debug.Log("calling shapeshift");
                    //    ShapeshiftController shapeshiftController = FindObjectOfType<ShapeshiftController>();
                    //    if (shapeshiftController != null)
                    //    {
                    //        shapeshiftController.TransformIntoEnemy(enemyType.enemyType);
                    //    }
                    //}

                    Destroy(gameObject);
                }

            }

            Destroy(gameObject); 
        }
        else if (other.CompareTag("Wall"))
        {
            Debug.Log("Beam hit the wall");
            Destroy(gameObject); 
        }
    }

   
    private void OnTriggerEnter(Collider other)
    {
        HandleCollision(other);
    }

    private void OnCollisionEnter(Collision collision)
    {
        HandleCollision(collision.collider);
    }
}
