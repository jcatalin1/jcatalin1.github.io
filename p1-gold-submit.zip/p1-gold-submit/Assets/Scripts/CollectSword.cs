using System.Collections;
using UnityEngine;

public class SwordPickup : MonoBehaviour
{
    public AudioClip collectSound;        // Sound to play when the sword is collected
    public AudioClip unlockWeaponSound;   // Sound to play when a new weapon is unlocked
    private bool isCollected = false;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !isCollected)
        {
           
            if (CompareTag("Sword"))
            {
                Debug.Log("sword collected");
                isCollected = true;
                CollectSword();

            }
            if (CompareTag("Bow"))
            {
                Debug.Log("only a bow");
                CollectSword();

            }
           

        }
    }

    private void CollectSword()
    {
        // Play the collect sound
        if (collectSound != null)
        {
            AudioSource.PlayClipAtPoint(collectSound, transform.position);
        }

        // Play the unlock weapon sound
        if (unlockWeaponSound != null)
        {
            AudioSource.PlayClipAtPoint(unlockWeaponSound, transform.position);
        }

    }

}
