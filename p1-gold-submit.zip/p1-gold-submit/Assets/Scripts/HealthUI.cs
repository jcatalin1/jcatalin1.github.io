using UnityEngine;
using UnityEngine.UI;

public class HealthUI : MonoBehaviour
{
    public PlayerHealth playerHealth; 
    public Image[] heartImages; 
    public Sprite fullHeartSprite; 
    public Sprite emptyHeartSprite; 

    void Update()
    {
        UpdateHealthDisplay();
    }

    void UpdateHealthDisplay()
    {
        int health = playerHealth.currentHealth;
        for (int i = 0; i < heartImages.Length; i++)
        {
            if (i < health)
                heartImages[i].sprite = fullHeartSprite; 
            else
                heartImages[i].sprite = emptyHeartSprite; 
        }
    }
}
