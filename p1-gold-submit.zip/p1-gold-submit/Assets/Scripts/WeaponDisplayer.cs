using UnityEngine;
using UnityEngine.UI;

public class WeaponDisplayer : MonoBehaviour
{
    public Inventory inventory;
    public Image mainWeaponImage;
    public Image alternateWeaponImage;

    public Sprite defaultWeaponSprite;
    public Sprite swordSprite;
    public Sprite bowSprite;
    public Sprite boomerangSprite;  
    public Sprite bombSprite;      

    // Start is called before the first frame update
    void Start()
    {
        if (mainWeaponImage == null || alternateWeaponImage == null)
        {
            Debug.LogError("Main and Alternate Weapon Images are not assigned.");
            return;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (inventory != null)
        {
            string currentMainWeapon = inventory.GetCurrentWeapon();
            string currentAlternateWeapon = inventory.GetAlternateWeapon();

            mainWeaponImage.sprite = GetWeaponSprite(currentMainWeapon);
            alternateWeaponImage.sprite = GetWeaponSprite(currentAlternateWeapon);
        }
    }

    Sprite GetWeaponSprite(string weaponName)
    {
        switch (weaponName)
        {
            case "Sword":
                return swordSprite;
            case "Bow":
                return bowSprite;
            case "Boomerang":         
                return boomerangSprite;
            case "Bomb":               
                return bombSprite;
            default:
                return defaultWeaponSprite;
        }
    }
}
