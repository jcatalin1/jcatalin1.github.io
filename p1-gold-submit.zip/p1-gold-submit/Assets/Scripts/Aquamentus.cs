using System.Collections;
using UnityEngine;

public class Aquamentus : MonoBehaviour
{
    [Header("Movement Settings")]
    public float patrolSpeed = 2f; // Speed of patrolling movement
    public float patrolDistance = 3f; // Distance to patrol back and forth

    [Header("Shooting Settings")]
    public GameObject fireballPrefab; // Prefab for the fireball
    public float fireballSpeed = 5f; // Speed of the fireball
    public float shootCooldown = 2f; // Cooldown time between shooting

    [Header("Player Detection")]
    public Transform player; // Reference to the player

    [Header("Animations")]
    public float animationSpeed = 0.1f;
    public Sprite[] sprites;
    public Sprite[] shootingSprites;
    private SpriteRenderer spriteRenderer;
    private int currentSpriteIndex;

    [Header("Audio")]
    public AudioClip enemySound;
    private AudioSource audioSource; // Reference to AudioSource component


    private Vector3 initialPosition; // Starting position for patrolling
    private bool movingRight = true; // Flag to control movement direction
    private bool isShooting = false; // Flag to check if Aquamentus is currently shooting
    private float timer;

    void Start()
    {
        InitializeAquamentus();
    }

    private void OnEnable()
    {
        InitializeAquamentus();

    }

    void OnDisable()
    {
        // Stop all coroutines when the enemy is deactivated
        StopAllCoroutines();
    }

    void InitializeAquamentus()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        audioSource = GetComponent<AudioSource>();
        initialPosition = transform.position; // Store initial position for patrolling
        StopAllCoroutines();
        StartCoroutine(PatrolRoutine());
        StartCoroutine(ShootFireballs());
    }

    private void Update()
    {
        UpdateAnimation();
        if (enemySound && !audioSource.isPlaying)
        {
            audioSource.clip = enemySound;
            audioSource.Play();
        }
    }

    IEnumerator PatrolRoutine()
    {
        while (true)
        {
            // Handle patrol movement
            if (movingRight)
            {
                transform.Translate(Vector2.right * patrolSpeed * Time.deltaTime);
                if (transform.position.x >= initialPosition.x + patrolDistance)
                {
                    movingRight = false;
                }
            }
            else
            {
                transform.Translate(Vector2.left * patrolSpeed * Time.deltaTime);
                if (transform.position.x <= initialPosition.x - patrolDistance)
                {
                    movingRight = true;
                }
            }


            yield return null; // Wait for the next frame
        }
    }

    IEnumerator ShootFireballs()
    {
        while (true)
        {
            Debug.Log("Shoot Fireballs");
            isShooting = true;

            // Calculate direction to shoot fireballs in a spread pattern
            Vector3 directionToPlayer = (player.position - transform.position).normalized;
            Vector3 leftSpread = Quaternion.Euler(0, 0, 15) * directionToPlayer;  // Left spread angle
            Vector3 rightSpread = Quaternion.Euler(0, 0, -15) * directionToPlayer; // Right spread angle

            Debug.Log($"DirectionToPlayer: {directionToPlayer}, leftSpread: {leftSpread}, rightSpread: {rightSpread}");

            // Instantiate and shoot fireballs
            ShootFireball(directionToPlayer);
            ShootFireball(leftSpread);
            ShootFireball(rightSpread);

            yield return new WaitForSeconds(shootCooldown); // Wait for cooldown before next shoot
            isShooting = false;
        }

    }

    void ShootFireball(Vector3 direction)
    {
        // Instantiate a fireball and set its direction and speed
        GameObject fireball = Instantiate(fireballPrefab, transform.position, Quaternion.identity); // Spawn at Aquamentus position
        Rigidbody rb = fireball.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = direction * fireballSpeed;
            Debug.Log("Fireball velocity: " + rb.velocity);
        }
    }

    void UpdateAnimation()
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            currentSpriteIndex = (currentSpriteIndex + 1) % 2;
            spriteRenderer.sprite = isShooting ?
                shootingSprites[currentSpriteIndex] : sprites[currentSpriteIndex];
        }
    }
}
