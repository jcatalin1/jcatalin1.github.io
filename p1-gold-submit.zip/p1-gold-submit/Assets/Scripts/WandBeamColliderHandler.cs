using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WandBeamColliderHandler : MonoBehaviour
{
    private Beam parentBeam;

    public void Initialize(Beam beam)
    {
        parentBeam = beam;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (parentBeam != null)
        {
            parentBeam.HandleCollision(other);
        }
        else
        {
            Debug.LogError("Parent Beam not initialized!");
        }
    }
}
