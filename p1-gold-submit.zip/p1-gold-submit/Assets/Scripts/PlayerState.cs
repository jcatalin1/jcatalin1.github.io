using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PlayerState
{
    public enum State
    {
        Player,  // Normal player form
        Keese,
        Stalfos,
        Aquamentus,
        Gel,
        Goriya
    }

    private static State currentState = State.Player;

    public static bool IsPlayer()
    {
        return currentState == State.Player;
    }

    public static bool IsKeese()
    {
        return currentState == State.Keese;
    }

    public static bool IsStalfos()
    {
        return currentState == State.Stalfos;
    }

    public static bool IsAquamentus()
    {
        return currentState == State.Aquamentus;
    }

    public static bool IsGel()
    {
        return currentState == State.Gel;
    }

    public static bool IsGoriya()
    {
        return currentState == State.Goriya;
    }

    public static void RevertToPlayer()
    {
        currentState = State.Player;
    }

    public static void TransformToEnemy(State enemyState)
    {
        currentState = enemyState;
    }
}
