using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public int rupee_count = 0;
    public int key_count = 0;
    public int bomb_count = 0;
    private string currentWeapon = "";
    private string currentAlternateWeapon = "Bow";
    private PlayerHealth playerHealth;

    private List<string> alternateWeapons = new List<string> { "Bow", "Boomerang", "Bomb" };
    private int currentAltWeaponIndex = 0; 

    void Start()
    {
        playerHealth = GetComponent<PlayerHealth>(); 
    }

    public void AddRupees(Rupee rupee)
    {
        if (rupee != null)
        {
            int rupeeValue = rupee.GetRupeeValue();  
            if (rupee_count >= 9999)
            {
                //dont add more rupees
            }
            else
            {
                rupee_count += rupeeValue;
            }

            Debug.Log("Collected " + rupeeValue + " rupees! Total rupees: " + rupee_count);
        }
    }

    public void SetMaxResources()
    {
        // just rupees for now
        if (rupee_count < 9999)
        {
            rupee_count = 9999;
        }
        //keys
        if(key_count < 9999)
        {
            key_count = 9999; 
        }
        //bomb
        if (bomb_count < 9999)
        {
            bomb_count = 9999; 
        }
    }


    public int GetRupees()
    {
        return rupee_count;
    }

    public void AddKey(int num_keys)
    {
        key_count += num_keys;
    }

    public void RemoveKey()
    {
        key_count--;
    }

    public int GetKeys()
    {
        return key_count;
    }

    public void PickUpWeapon(string weapon)
    {
        currentWeapon = weapon;
        Debug.Log("Picked up weapon: " + weapon);
    }

    public void RestoreHealth() //for now, hearts restore 1 health
    {
        if (playerHealth != null)
        {
            playerHealth.Heal(1); 
            Debug.Log("Restored " + 1 + " health. Current health: " + playerHealth.GetCurrentHealth());
        }
    }

    public void DropWeapon()
    {
        currentWeapon = "";
        Debug.Log("Dropped weapon");
    }

    public string GetCurrentWeapon()
    {
        return currentWeapon;
    }

    public string GetAlternateWeapon()
    {
        return currentAlternateWeapon;
    }

    public void CycleAlternateWeapon()
    {
        currentAltWeaponIndex = (currentAltWeaponIndex + 1) % alternateWeapons.Count;
        currentAlternateWeapon = alternateWeapons[currentAltWeaponIndex];
        Debug.Log("Switched to alternate weapon: " + currentAlternateWeapon);
    }

    public void AddBomb(int num_bombs)
    {
        bomb_count += num_bombs;
        Debug.Log("Added " + num_bombs + " bombs. Total bombs: " + bomb_count);
    }

    public void UseBomb()
    {
        if (bomb_count > 0)
        {
            bomb_count--;
            Debug.Log("Used a bomb. Bombs left: " + bomb_count);
        }
        else
        {
            Debug.Log("No bombs left!");
        }
    }

    public int GetBombs()
    {
        return bomb_count;
    }


}
