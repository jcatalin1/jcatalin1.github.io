using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class DoorTrigger : MonoBehaviour
{
    public bool instantTransition = false; 
    public Vector3 cameraShift; // The shift amount for the camera when this door is triggered
    public Vector3 playerShift; 
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !CameraController.instance.IsTransitioning())
        {
            Debug.Log("Door Transition");
            // Disable Player collisions
            other.gameObject.GetComponent<Collider>().enabled = false;
            // Trigger the camera to start moving
            if (instantTransition == true)
            {
                CameraController.instance.StartRoomTransitionInstant(cameraShift, playerShift);
            }
            else
            {
                CameraController.instance.StartRoomTransition(cameraShift, playerShift);
            }
        }
    }
}
