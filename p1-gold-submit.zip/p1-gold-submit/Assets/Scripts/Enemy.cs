using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public EnemyType.Type enemyType;

    public int maxHealth = 3;
    public int currentHealth;
    public int damage = 1;
    public float knockbackForce = 1f;
    public float hitStunDuration = 0.5f;
    public SpriteRenderer spriteRenderer;
    public Color hitColor = Color.red;
    public GameObject[] powerUpPrefabs; 
    public float powerUpDropChance = 0.5f; //50% chance to drop something rn


    [Header("Key Holding Settings")]
    public bool isHoldingKey = false; // If true, this enemy holds a key
    public GameObject keyPrefab; // Key prefab to drop upon death
    private GameObject keyInstance; // The key object under the enemy sprite
    private Sprite keySprite;
    public GameObject soulPrefab;

    [Header("Audio")]
    public AudioClip hitAudio;

    private bool isHitStunned;
    private Rigidbody rb;
    void Start()
    {
        currentHealth = maxHealth;
        isHitStunned = false;
        rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.drag = 10f;
        }
        if (isHoldingKey)
        {
            // Instantiate and place the key sprite beneath the enemy
            ShowKeyUnderEnemy();
        }
    }

    public void SetEnemyType(EnemyType.Type type)
    {
        enemyType = type;
    }


    void ShowKeyUnderEnemy()
    {
        // Create a new GameObject for the key sprite and place it below the enemy
        keyInstance = new GameObject("Key Under Enemy");
        SpriteRenderer keySpriteRenderer = keyInstance.AddComponent<SpriteRenderer>();
        keySprite = keyPrefab.GetComponent<SpriteRenderer>().sprite;
        keySpriteRenderer.sprite = keySprite;
        spriteRenderer.sortingOrder++;
        keySpriteRenderer.sortingOrder = spriteRenderer.sortingOrder - 1; // Ensure the key is drawn beneath the enemy
        keyInstance.transform.SetParent(transform); // Attach to the enemy
        keyInstance.transform.localPosition = Vector3.zero; // Place at the same position
    }

    public void TakeDamage(int damage, Vector3 knockbackDirection)
    {
        if (isHitStunned) return;

        // Play the Sound
        if (hitAudio != null)
        {
            AudioManager.instance.PlaySound(hitAudio, transform.position);
        }

        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            Die();
        }
        else
        {
            StartCoroutine(HitStunCoroutine(knockbackDirection));
        }
    }

    public void TakeDamageByWandBeam(int damage, Vector3 knockbackDirection)
    {
        Debug.Log("taking damage by wand beam");
        if (isHitStunned) return;

        // Play the Sound
        if (hitAudio != null)
        {
            AudioManager.instance.PlaySound(hitAudio, transform.position);
        }

        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            DieAndDropSoul();
        }
        else
        {
            StartCoroutine(HitStunCoroutine(knockbackDirection));
        }
    }

    // Enemy death logic
    void Die()
    {

        if (isHoldingKey)
        {
            DropKey();
        }
        else
        {
            DropPowerUp();
        }
        Destroy(gameObject);
    }

    // Enemy death logic
    void DieAndDropSoul()
    {

        Debug.Log("died by wand beam");
        DropSoul();
        if (isHoldingKey)
        {
            DropKey();
        }
        Destroy(gameObject);
    }

    void DropKey()
    {
        if (keyPrefab != null)
        {
            Instantiate(keyPrefab, transform.position, Quaternion.identity);
            Debug.Log("Key dropped!");
        }
    }

    void DropPowerUp()
    {
        if (Random.value <= powerUpDropChance)
        {
            int index = Random.Range(0, powerUpPrefabs.Length);
            GameObject powerUp = Instantiate(powerUpPrefabs[index], transform.position, Quaternion.identity);
            Debug.Log($"Dropped {powerUp.name}");
        }
    }

    private void DropSoul()
    {
        if (soulPrefab != null)
        {
            GameObject soul = Instantiate(soulPrefab, transform.position, Quaternion.identity);
            Soul soulComponent = soul.GetComponent<Soul>();
            if (soulComponent != null)
            {
                soulComponent.SetEnemyType(enemyType); // Assign the enemy type to the soul
            }
        }
    }




    IEnumerator HitStunCoroutine(Vector3 knockbackDirection)
    {
        isHitStunned = true;
        StartCoroutine(FlashEffectCoroutine());

        // Disable the EnemyMovement script to prevent it from overriding the knockback
        EnemyMovement movementScript = GetComponent<EnemyMovement>();
        if (movementScript != null)
        {
            Debug.Log("disabling movement script");
            // Stop all coroutines running in the EnemyMovement script
            movementScript.StopAllCoroutines();
            movementScript.enabled = false;
        }

        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            Vector3 tempKnockbackDirection = knockbackDirection.normalized;
            // Determine if the knockback should be horizontal or vertical
            bool isHorizontalKnockback = Mathf.Abs(tempKnockbackDirection.x) > Mathf.Abs(tempKnockbackDirection.y);
            if (isHorizontalKnockback)
            {
                // Horizontal knockback
                tempKnockbackDirection.y = 0; // Set vertical component to zero
                tempKnockbackDirection.x = Mathf.Sign(tempKnockbackDirection.x); // Ensure it's only -1 or 1
            }
            else
            {
                // Vertical knockback
                tempKnockbackDirection.x = 0; // Set horizontal component to zero
                tempKnockbackDirection.y = Mathf.Sign(tempKnockbackDirection.y); // Ensure it's only -1 or 1
            }
            float tempKnockbackForce = knockbackForce;

            // Check for wall collisions in the knockback direction
            RaycastHit hit;
            bool wallHit = false;
            if (isHorizontalKnockback)
            {
                // Check for walls to the left or right
                wallHit = Physics.Raycast(transform.position, Vector3.right * tempKnockbackDirection.x, out hit, 2f, LayerMask.GetMask("Wall"));
            }
            else
            {
                // Check for walls above or below
                wallHit = Physics.Raycast(transform.position, Vector3.up * tempKnockbackDirection.y, out hit, 2f, LayerMask.GetMask("Wall"));
            }
            if (wallHit)
            {
                Debug.Log("Reduced Knockback");
                // Reduce or cancel the knockback force if a wall is too close
                float distanceToWall = hit.distance;
                tempKnockbackForce = tempKnockbackForce / distanceToWall;
                Debug.Log($"Reducing knockback force. Distance to wall: {distanceToWall}, Adjusted Force: {tempKnockbackForce}");

                // If too close to the wall, cancel the knockback
                if (distanceToWall < 2f)
                {
                    Debug.Log("Knockback canceled due to proximity to the wall.");
                    tempKnockbackForce = 0f;
                }
            }

            // Apply the adjusted knockback force
            if (tempKnockbackForce > 0f)
            {
                rb.AddForce(tempKnockbackDirection * tempKnockbackForce, ForceMode.Impulse);
                Debug.Log($"Knockback applied. Direction: {tempKnockbackDirection}, Force: {tempKnockbackForce}, Resulting velocity: {rb.velocity}");
            }
        }
        else
        {
            Debug.LogError("Rigidbody component is missing on the enemy!");
        }

        yield return new WaitForSeconds(hitStunDuration);

        rb.velocity = Vector3.zero;
        rb.drag = 0f;

        // Re-enable the EnemyMovement script
        if (movementScript != null)
        {
            movementScript.enabled = true;
            movementScript.InitializeMovement();
        }
        isHitStunned = false;
    }


    IEnumerator FlashEffectCoroutine()
    {
        float elapsed = 0f;
        bool isFlashOn = true;

        while (elapsed < hitStunDuration)
        {
            elapsed += 0.1f;
            spriteRenderer.color = isFlashOn ? hitColor : Color.white;
            isFlashOn = !isFlashOn;
            yield return new WaitForSeconds(0.1f);
        }

        spriteRenderer.color = Color.white;
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("Player hit by enemy");
            PlayerHealth playerHealth = collision.GetComponent<PlayerHealth>();

            if (playerHealth != null)
            {
              
                if (enemyType == EnemyType.Type.Stalfos && PlayerState.IsStalfos())
                {
                    Debug.Log("No damage taken because player is Stalfos and enemy is Stalfos.");
                    return; // Prevent damage
                }

                Vector3 knockbackDirection = (collision.transform.position - transform.position).normalized;
                playerHealth.TakeDamage(damage, knockbackDirection);
                 //testing
            }
        }
    }


}
