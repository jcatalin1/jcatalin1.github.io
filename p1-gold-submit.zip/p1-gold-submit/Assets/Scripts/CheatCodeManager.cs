using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class CheatCodeManager : MonoBehaviour
{
    public static bool god_mode = false;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            god_mode = !god_mode; 
            Debug.Log("God Mode: " + (god_mode ? "Activated" : "Deactivated"));
            Inventory playerInventory = FindObjectOfType<Inventory>();
            if (playerInventory != null)
            {
                playerInventory.SetMaxResources();
            }
        }
    }
}
