using UnityEngine;

public class EnemyType : MonoBehaviour
{
    public enum Type
    {
        Stalfos,
        Keese,
        Gel,
        Aquamentus,
        Goriya
      
    }

    public Type enemyType;
}
