using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoriyaTransformation : MonoBehaviour
{
    public Sprite goriyaSprite;

    private ArrowKeyMovement originalPlayerMovement;
    private SpriteRenderer originalPlayerSpriteRenderer;
    private Inventory playerInventory;
    void Start()
    {
        originalPlayerMovement = GetComponent<ArrowKeyMovement>();
        originalPlayerSpriteRenderer = GetComponent<SpriteRenderer>();
        playerInventory = GetComponent<Inventory>();
    }

    public void TransformToGoriya()
    {
        PlayerState.TransformToEnemy(PlayerState.State.Goriya);
        originalPlayerSpriteRenderer.sprite = goriyaSprite;
        originalPlayerMovement.isGoriya = true;
        Debug.Log("Player transformed into Goriya");

    }
}
