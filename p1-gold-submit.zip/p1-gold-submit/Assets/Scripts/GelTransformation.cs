using UnityEngine;

public class GelTransformation : MonoBehaviour
{
    
    public Sprite gelSprite;
    public Vector3 gelSpawnOffset = new Vector3(1, 0, 0); // Offset for spawning the Gel clone

    private ArrowKeyMovement originalPlayerMovement;
    private SpriteRenderer originalPlayerSpriteRenderer;
    private Inventory playerInventory;

    private GameObject gelPlayer; // Reference to the Gel clone

    void Start()
    {
        originalPlayerMovement = GetComponent<ArrowKeyMovement>();
        originalPlayerSpriteRenderer = GetComponent<SpriteRenderer>();
        playerInventory = GetComponent<Inventory>();
    }

    public void TransformToGel()
    {
        PlayerState.TransformToEnemy(PlayerState.State.Gel);
        originalPlayerSpriteRenderer.sprite = gelSprite;

        // Spawn the Gel clone at an offset next to the player
        SpawnGelClone();

        // Controls on the original player
        originalPlayerMovement.enableWASD = false;
        originalPlayerMovement.enableArrowKeys = true; // Original player now controlled by arrowKeys only

        // isGel
        originalPlayerMovement.isGel = true;
        
        Debug.Log("Player has transformed into Gel!");
    }

    void SpawnGelClone()
    {
        Vector3 spawnPosition = transform.position + gelSpawnOffset;
        gelPlayer = Instantiate(gameObject, spawnPosition, Quaternion.identity);

        // Destroy the 'Wand' component or object on the gelPlayer if it exists
        Transform wandTransform = gelPlayer.transform.Find("Wand(Clone)");
        if (wandTransform != null)
        {
            Destroy(wandTransform.gameObject);
            Debug.Log("Wand child object destroyed from gel player.");
        }

        AudioSource gel_audio_source = gelPlayer.GetComponent<AudioSource>();
        if (gel_audio_source) gel_audio_source.enabled = false;

        gelPlayer.GetComponent<ArrowKeyMovement>().enableArrowKeys = false; // Gel clone controlled by WASD
        gelPlayer.GetComponent<SpriteRenderer>().sprite = gelSprite;
        gelPlayer.GetComponent<ArrowKeyMovement>().isGel = true;
        gelPlayer.GetComponent<PlayerHealth>().enabled = false;
    }

}
