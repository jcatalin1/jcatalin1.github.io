using UnityEngine;

public class StalfosTransformation : MonoBehaviour
{
    public SpriteRenderer playerSpriteRenderer; 
    public Sprite stalfosSprite; 
    public Inventory playerInventory; 
    private ArrowKeyMovement arrowKeyMovement; 

    void Start()
    {
        arrowKeyMovement = GetComponent<ArrowKeyMovement>(); 
    }

    public void TransformToStalfos()
    {
        PlayerState.TransformToEnemy(PlayerState.State.Stalfos); 
        playerSpriteRenderer.sprite = stalfosSprite; 
        EquipStalfosWeapon(); //not really needed i think 
        arrowKeyMovement.isStalfos = true; 
        Debug.Log("Player has transformed into Stalfos!");
    }


    private void EquipStalfosWeapon()
    {
        playerInventory.PickUpWeapon("Sword");
    }
}
