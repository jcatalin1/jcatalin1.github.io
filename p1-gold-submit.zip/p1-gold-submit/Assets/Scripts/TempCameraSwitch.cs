using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class TempCameraSwitch : MonoBehaviour
{
    public Camera goingToCamera;        // The camera to switch to
    public Camera comingFromCamera;     // The current active camera
    public Transform player;            // Reference to the player
    public Transform targetPosition;    // The position to move the player to
    public GameController coroutineRunner;  // Drag and drop your GameController object here

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            player.position = targetPosition.position;
            StartRoomTransition();
        }
    }


    private void StartRoomTransition()
    {
        goingToCamera.gameObject.SetActive(true);

        //yield return new WaitForSeconds(1f);

        comingFromCamera.gameObject.SetActive(false);
    }
}
