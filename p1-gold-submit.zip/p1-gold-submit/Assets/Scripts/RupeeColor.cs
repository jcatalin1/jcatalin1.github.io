using UnityEngine;

public class Rupee : MonoBehaviour
{
    public enum RupeeColor
    {
        Green,
        Blue,
        Red
    }

    public RupeeColor rupeeColor;
    private SpriteRenderer spriteRenderer;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();

        if (spriteRenderer != null)
        {
            UpdateRupeeColor();
        }
        else
        {
            Debug.LogError("SpriteRenderer component is missing!");
        }
    }


    public int GetRupeeValue()
    {
        switch (rupeeColor)
        {
            case RupeeColor.Green:
                return 1;
            case RupeeColor.Blue:
                return 5;
            case RupeeColor.Red:
                return 20;
            default:
                return 0; 
        }
    }


    void UpdateRupeeColor()
    {
        switch (rupeeColor)
        {
            case RupeeColor.Green:
                spriteRenderer.color = Color.green; 
                break;
            case RupeeColor.Blue:
                spriteRenderer.color = Color.blue; 
                break;
            case RupeeColor.Red:
                spriteRenderer.color = Color.red; 
                break;
        }
    }
}
