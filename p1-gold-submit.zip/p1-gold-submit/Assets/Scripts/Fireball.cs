using UnityEngine;

public class Fireball : MonoBehaviour
{
    public float lifetime = 3f; // How long the fireball lasts before disappearing
    public int damage = 1;
    public Sprite[] sprites;
    public float animationSpeed = 0.1f;

    private float timer;
    private SpriteRenderer spriteRenderer;
    private int currentSpriteIndex;
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        // Destroy the fireball after a set time to prevent it from existing indefinitely
        Destroy(gameObject, lifetime);
    }

    private void Update()
    {
        UpdateSprite();
    }

    void OnTriggerEnter(Collider other)
    {
        // Handle collision with player or other objects
        if (other.CompareTag("Player"))
        {
            // Assuming you have a PlayerHealth script to handle player damage
            Debug.Log("Player hit by fireball");
            PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(damage, Vector3.zero);
            }

            // Destroy the fireball upon hitting the player
            Destroy(gameObject);
        }
        else if (other.CompareTag("Wall"))
        {
            // Destroy the fireball upon hitting a wall
            Destroy(gameObject);
        }
    }

    void UpdateSprite()
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            currentSpriteIndex = (currentSpriteIndex + 1) % 4;
            spriteRenderer.sprite = sprites[currentSpriteIndex];

        }
    }
}
