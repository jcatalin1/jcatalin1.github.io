using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class Player : MonoBehaviour
{
    private Inventory playerInventory;
    public bool isGrabbed = false;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Sword"))
        {
            playerInventory.PickUpWeapon("Sword");
            Destroy(other.gameObject);
        }
        else if (other.CompareTag("Bow"))
        {
            //playerInventory.PickUpWeapon("Bow");
            Destroy(other.gameObject);
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            playerInventory.DropWeapon();
        }

        if (PlayerState.IsPlayer())
        {
            //Debug.Log("Player is in normal form.");
        }
        else if (PlayerState.IsStalfos())
        {
            Debug.Log("Player is currently transformed into Stalfos.");
        }
        else if (PlayerState.IsGoriya())
        {
            Debug.Log("Player is currently transformed into Goriya.");
        }
        else if (PlayerState.IsKeese())
        {
            Debug.Log("Player is currently transformed into Keese.");
        }
    }
}
