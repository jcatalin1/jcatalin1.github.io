using UnityEngine;

public class ArrowColliderHandler : MonoBehaviour
{
    private Arrow parentArrow;

    public void Initialize(Arrow arrow)
    {
        parentArrow = arrow;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (parentArrow != null)
        {
            parentArrow.HandleCollision(other);
        }
        else
        {
            Debug.LogError("Parent Arrow not initialized!");
        }
    }
}
