using System.Collections;
using UnityEngine;

public class Boomerang : MonoBehaviour
{
    public float speed = 5f;
    public float returnSpeed = 7f;
    public float maxDistance = 4f;
    public float goriyaMaxDistance = 10f; // Extended range for Goriya
    public float rotationSpeed = 360f;
    public int damage = 1;
    public bool isPlayer = true;
    public GameObject holder;

    private Vector3 startPosition;
    private Vector3 moveDirection;
    private bool returning;
    private Transform playerTransform;

    public static bool boomerangActive = false;

    public AudioClip swingSound;

    void Start()
    {
        startPosition = transform.position;
        playerTransform = isPlayer ? GameObject.FindWithTag("Player").transform : holder.transform;
        boomerangActive = true;

        // Check if the player is Goriya and extend boomerang range if true
        if (PlayerState.IsGoriya())
        {
            maxDistance = goriyaMaxDistance;
            Debug.Log("Player is Goriya. Extended boomerang range!");
        }

        if (swingSound != null)
        {
            AudioSource.PlayClipAtPoint(swingSound, transform.position);
        }
    }

    public void Initialize(Vector2 direction)
    {
        moveDirection = new Vector3(direction.x, direction.y, 0).normalized;
        transform.rotation = Quaternion.LookRotation(Vector3.forward, moveDirection);
        GetComponent<Rigidbody>().velocity = moveDirection * speed;
    }

    void Update()
    {
        if (!returning)
        {
            transform.position += moveDirection * speed * Time.deltaTime;
            transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
            if (Vector3.Distance(startPosition, transform.position) >= maxDistance)
            {
                returning = true;
            }
        }
        else
        {
            // Move the boomerang back toward the player in the 2D plane
            if (playerTransform)
            {
                Vector3 targetPosition = new Vector3(playerTransform.position.x, playerTransform.position.y, transform.position.z);
                transform.position = Vector3.MoveTowards(transform.position, targetPosition, returnSpeed * Time.deltaTime);

                // Rotate the boomerang as it returns
                transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);

                // If boomerang reaches the player
                if (Vector3.Distance(transform.position, playerTransform.position) < 0.1f)
                {
                    boomerangActive = false;
                    Destroy(gameObject); // Boomerang collected/destroyed
                }
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (isPlayer)
        {
            if (other.CompareTag("Enemy"))
            {
                Enemy enemy = other.GetComponent<Enemy>();
                if (enemy != null)
                {
                    Vector2 knockbackDirection = (other.transform.position - transform.position).normalized;
                    enemy.TakeDamage(damage, knockbackDirection * 2);
                    Debug.Log("Enemy hit by boomerang");
                }
            }
        }
        else
        {
            if (other.CompareTag("Player"))
            {
                Debug.Log("Player hit by boomerang");
                PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();
                if (playerHealth != null)
                {
                    //playerHealth.TakeDamage(damage, Vector3.zero);
                    Vector3 knockbackDirection = (other.transform.position - transform.position).normalized;
                    playerHealth.TakeDamage(damage, knockbackDirection);
                }
            }
        }

        if (other.CompareTag("Wall"))
        {
            Debug.Log("Boomerang hit the wall");
            returning = true;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.CompareTag("Wall"))
        {
            Debug.Log("Boomerang hit the wall");
            returning = true;
        }
    }

    public static bool CanThrowBoomerang()
    {
        return !boomerangActive;
    }

    public static bool CanThrowBoomerangPlayer(Boomerang boomerangInstance)
    {
        return !boomerangActive && boomerangInstance.isPlayer;
    }

}
