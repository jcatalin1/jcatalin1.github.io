using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class TempCameraLastResort: MonoBehaviour
{

    public Transform player;            // Reference to the player
    public Transform targetPosition;    // The position to move the player to
    public GameObject camera1; // Assign the first camera
    public GameObject camera2; // Assign the second camera

    private void Start()
    {
        // Ensure the first camera is active and the second one is inactive at the start
        camera1.SetActive(true);
        camera2.SetActive(false);
    }

    // This method is called when another collider enters the trigger
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) // Ensure the player is the object triggering the switch
        {
            // Switch camera states
            bool isCamera1Active = camera1.activeSelf;
            player.position = targetPosition.position;
            camera1.SetActive(!isCamera1Active);
            camera2.SetActive(isCamera1Active);
        }
    }
}
