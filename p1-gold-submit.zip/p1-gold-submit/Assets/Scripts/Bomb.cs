using System.Collections;
using UnityEngine;

public class Bomb : MonoBehaviour
{
    public float blastRadius = 2.0f; // Radius of explosion
    public float delay = 3.0f;       // Delay before explosion
    public int damage = 2;           // Damage to enemies
    public GameObject explosionEffect; // Visual explosion effect
    public AudioClip explosionSound; // Explosion sound
    public AudioClip placementSound; // Placement sound when the bomb is placed
    public int bombCount = 3;        // Number of bombs player has
    public float knockbackForce = 5.0f; // Knockback force from explosion
    public float explosionEffectDuration = 2.0f; // Time before explosion effect is destroyed

    void Start()
    {
        PlayPlacementSound(); // Play the placement sound when the bomb is instantiated
        StartCoroutine(ExplodeAfterDelay());
    }

    void PlayPlacementSound()
    {
        if (placementSound != null)
        {
            AudioSource.PlayClipAtPoint(placementSound, transform.position);
        }
    }

    IEnumerator ExplodeAfterDelay()
    {
        yield return new WaitForSeconds(delay);
        Explode();
    }

    void Explode()
    {
        AudioSource.PlayClipAtPoint(explosionSound, transform.position);

        GameObject explosion = Instantiate(explosionEffect, transform.position, Quaternion.identity);

        Destroy(explosion, explosionEffectDuration);

        Collider[] hitEnemies = Physics.OverlapSphere(transform.position, blastRadius);
        foreach (Collider hit in hitEnemies)
        {
            if (hit.CompareTag("Enemy"))
            {
                Enemy enemy = hit.GetComponent<Enemy>();
                if (enemy != null)
                {
                    Rigidbody rb = enemy.GetComponent<Rigidbody>();
                    Vector3 knockbackDirection = (enemy.transform.position - transform.position).normalized;
                    rb.AddForce(knockbackDirection * knockbackForce, ForceMode.Impulse);
                    enemy.TakeDamage(damage, knockbackDirection);
                }
            }
        }

        Destroy(gameObject);
    }
}
