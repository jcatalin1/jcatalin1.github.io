using System.Collections;
using UnityEngine;

public class Sword : MonoBehaviour
{
    public float attackDuration = 0.3f;
    public Vector2 offsetUp = new Vector2(0, 0.5f);
    public Vector2 offsetDown = new Vector2(0, -0.5f);
    public Vector2 offsetLeft = new Vector2(-0.5f, 0);
    public Vector2 offsetRight = new Vector2(0.5f, 0);
    public int swordDamage = 1;
    public Vector2 knockbackForce = new Vector2(2, 2);

    public Sprite upSprite;
    public Sprite downSprite;
    public Sprite leftSprite;
    public Sprite rightSprite;

    public GameObject beamPrefab;
    public SpriteRenderer spriteRenderer;
    private PlayerHealth playerHealth;

    public AudioClip swingSound; // Sound effect for sword swing
    public AudioClip beamSound;  // Sound effect for beam shooting

    private ArrowKeyMovement arrowKeyMovement;


    void Start()
    {
        arrowKeyMovement = GetComponent<ArrowKeyMovement>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void Initialize(PlayerHealth health, Vector2 direction)
    {
        playerHealth = health;
        Attack(direction);
    }

    public void Attack(Vector2 direction)
    {
        Vector2 offset = Vector2.zero;
        if (direction == Vector2.up)
        {
            offset = offsetUp;
            spriteRenderer.sprite = upSprite;
        }
        else if (direction == Vector2.down)
        {
            offset = offsetDown;
            spriteRenderer.sprite = downSprite;
        }
        else if (direction == Vector2.left)
        {
            offset = offsetLeft;
            spriteRenderer.sprite = leftSprite;
        }
        else if (direction == Vector2.right)
        {
            offset = offsetRight;
            spriteRenderer.sprite = rightSprite;
        }

        transform.localPosition = offset;

        // Play sword swing sound
        if (swingSound != null)
        {
            AudioSource.PlayClipAtPoint(swingSound, transform.position);
        }
        if (playerHealth != null && playerHealth.IsFullHealth())
        {
            
            if (PlayerState.IsPlayer())
            {
                ShootBeam(direction);
            }
            else
            {
                Debug.Log("Player is Stalfos, cannot shoot beam.");
            }
        }


        StartCoroutine(DestroyAfterTime());
    }

    void ShootBeam(Vector2 direction)
    {
        GameObject beamInstance = Instantiate(beamPrefab, transform.position, Quaternion.identity);
        Beam beamScript = beamInstance.GetComponent<Beam>();
        if (beamScript != null)
        {
            beamScript.Initialize(direction);

            // Play beam shooting sound
            if (beamSound != null)
            {
                AudioSource.PlayClipAtPoint(beamSound, transform.position);
            }
        }
    }

    IEnumerator DestroyAfterTime()
    {
        yield return new WaitForSeconds(attackDuration);
        Destroy(gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            Enemy enemy = other.GetComponent<Enemy>();
            if (enemy != null)
            {
                Vector2 knockbackDirection = (other.transform.position - transform.position).normalized;
                enemy.TakeDamage(swordDamage, knockbackDirection * knockbackForce);
                Debug.Log("Enemy hit by sword");
            }
        }
    }
}
