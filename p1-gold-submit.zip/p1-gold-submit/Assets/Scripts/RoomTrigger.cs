using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomTrigger : MonoBehaviour
{
    public List<GameObject> enemiesInRoom; // Array to hold all enemies in this room
    public GameObject keyPrefab; 
    public Transform keySpawnPoint;
    public AudioClip roomAudio;

    private bool hasTriggered;
    private bool allEnemiesDefeated = false;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !hasTriggered) // Check if the player enters room
        {
            Debug.Log("Spawn Enemies");
            hasTriggered = true; // Prevent multiple triggers
            SpawnEnemies();
            StartCoroutine(CheckEnemiesDefeated()); // Start checking if all enemies are defeated
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player") && hasTriggered) // Check if the player exits room
        {
            Debug.Log("Despawn Enemies");
            hasTriggered = false; // Prevent multiple triggers
            DespawnEnemies();
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") && !hasTriggered) // Check if the player enters room
        {
            hasTriggered = true; // Prevent multiple triggers
        }
    }

    void SpawnEnemies()
    {
        foreach (GameObject enemy in enemiesInRoom)
        {
            if (enemy != null) 
            { 
                enemy.SetActive(true); // Activate each enemy
            }
        }
    }

    void DespawnEnemies()
    {
        // Deactivate all enemies at the start
        foreach (GameObject enemy in enemiesInRoom)
        {
            enemy.SetActive(false); // Deactivate enemies initially
        }
    }

    IEnumerator CheckEnemiesDefeated()
    {
        while (hasTriggered)
        {
            Debug.Log("CheckEnemiesDefeated");
            allEnemiesDefeated = true;
            // Check if all enemies are defeated
            foreach (GameObject enemy in enemiesInRoom)
            {
                if (enemy != null && enemy.activeInHierarchy)
                {
                    allEnemiesDefeated = false;
                    break;
                }
            }
            

            // If all enemies are defeated, spawn the key
            if (allEnemiesDefeated)
            {
                Debug.Log(allEnemiesDefeated);
                Debug.Log("All enemies defeated! Spawning key...");
                if (roomAudio != null)
                {
                    AudioManager.instance.PlaySound(roomAudio, transform.position);
                }
                SpawnKey();
                yield break; // Exit the coroutine
            }

            yield return new WaitForSeconds(1f); // Check every second
        }
    }

    void SpawnKey()
    {
        if (keyPrefab != null && keySpawnPoint != null)
        {
            Instantiate(keyPrefab, keySpawnPoint.position, Quaternion.identity);
            Destroy(gameObject);
        }
        else
        {
            Debug.LogWarning("Key prefab or key spawn point is not set!");
        }
    }

    void Start()
    {
        hasTriggered = false;
        DespawnEnemies();
    }

    private void Update()
    {
    }
}