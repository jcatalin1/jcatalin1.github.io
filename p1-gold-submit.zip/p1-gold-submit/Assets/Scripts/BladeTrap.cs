using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BladeTrap : MonoBehaviour
{
    public float movementSpeed = 4f; // Speed at which the Blade Trap moves
    public float detectionDistance = 5f; // Maximum distance to detect the player
    public float HorizontalMoveDistance = 4f;
    public float VerticalMoveDistance = 4f;

    private Vector3 initialPosition; // Store the initial position to return to
    private bool isMoving = false; // Flag to check if the Blade Trap is moving
    private bool isHorizontal = false;
    private bool isComingBack = false;
    private Vector3 moveDirection; // The direction in which the Blade Trap will move
    private Vector3 returnDirection; // The direction in which the Blade Trap will return


    void Start()
    {
        // Store the initial position of the Blade Trap
        initialPosition = transform.position;
    }

    void Update()
    {
        // Perform raycasts in four directions to check for the player
        if (!isMoving && !isComingBack)
        {
            CheckForPlayer();
        }
        else if (!isComingBack)
        {
            // Move the Blade Trap in the detected direction
            transform.position += moveDirection * movementSpeed * Time.deltaTime;
        }
    }

    void CheckForPlayer()
    {
        // Check for player in four directions: up, down, left, right
        if (RaycastForPlayer(Vector3.up) || RaycastForPlayer(Vector3.down))
        {
            isHorizontal = false;
            BeginMovement();
        }
        else if (RaycastForPlayer(Vector3.left) || RaycastForPlayer(Vector3.right))
        {
            isHorizontal = true;
            BeginMovement();
        }
    }

    bool RaycastForPlayer(Vector3 direction)
    {
        RaycastHit hit;
        // Perform the raycast in the specified direction
        if (Physics.Raycast(transform.position, direction, out hit, detectionDistance))
        {
            // Check if the hit object is the player
            if (hit.collider.CompareTag("Player"))
            {
                Debug.Log($"Player detected in direction: {direction}");
                moveDirection = direction; // Set the direction to move towards the player
                returnDirection = -direction; // Set the return direction to be the exact opposite
                return true; // Player detected
            }
        }
        return false; // No player detected
    }

    void BeginMovement()
    {
        isMoving = true; // Start moving
    }

    void FixedUpdate()
    {
        // If the Blade Trap is moving, check if it reached the maximum distance or collided with a wall
        if (isMoving)
        {
            float distanceFromStart = Vector3.Distance(transform.position, initialPosition);
            Debug.Log("Distance from Start: " + distanceFromStart);
            if ((isHorizontal && distanceFromStart >= HorizontalMoveDistance) || 
                (!isHorizontal && distanceFromStart >= VerticalMoveDistance) || 
                IsCollidingWithWallOrTrap())
            {
                StopAndReturn();
            }
        }
    }

    void StopAndReturn()
    {
        isMoving = false; // Stop moving
        isComingBack = true;
        moveDirection = returnDirection; // Clear the move direction
        StartCoroutine(ReturnToInitialPosition());
    }

    IEnumerator ReturnToInitialPosition()
    {
        Debug.Log("initialPosition: " + initialPosition);
        while (Vector3.Distance(transform.position, initialPosition) > 0.1f)
        {
            Debug.Log("Moving back to position1");
            Debug.Log("transform.position: " + transform.position + ", distanceToInitPos: " + Vector3.Distance(transform.position, initialPosition));
            // Move back to the initial position
            transform.position += moveDirection * (movementSpeed/2) * Time.deltaTime;
            yield return null;
        }
        transform.position = initialPosition; // Snap to the exact initial position
        isComingBack = false;
        Debug.Log("Back in initial position");
    }

    bool IsCollidingWithWallOrTrap()
    {
        // Check if the Blade Trap has collided with a wall
        RaycastHit hit;
        if (Physics.Raycast(transform.position, moveDirection, out hit, 0.1f)) {
            if (hit.collider.CompareTag("Wall")) {
                Debug.Log("Hit wall");
                return true;
            }
            else if (hit.collider.CompareTag("Enemy"))
            {
                Debug.Log("Hit enemy");
                return true;
            }
        }
        return false;
    }
}
