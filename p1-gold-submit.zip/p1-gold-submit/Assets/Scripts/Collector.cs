using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collector : MonoBehaviour
{
    Inventory inventory;
    public AudioClip rupee_collection_sound_clip;
    public AudioClip key_collection;

    void Start()
    {
        inventory = GetComponent<Inventory>();
        if (inventory == null)
        {
            Debug.LogWarning("GameObject does not have an Inventory component.");
        }
    }

    private void OnTriggerEnter(Collider coll)
    {
        GameObject object_collided_with = coll.gameObject;
        if (object_collided_with.CompareTag("rupee"))
        {
            Rupee rupee = object_collided_with.GetComponent<Rupee>();
            if (rupee != null && inventory != null)
            {
                inventory.AddRupees(rupee); 
            }
            Debug.Log("Collected rupee!");
            Destroy(object_collided_with);
            AudioSource.PlayClipAtPoint(rupee_collection_sound_clip, Camera.main.transform.position);
        }
        else if (object_collided_with.CompareTag("Sword"))
        {
            if (inventory != null)
            {
                inventory.PickUpWeapon("Sword");
            }

            Debug.Log("Picked up sword!");
            Destroy(object_collided_with);
        }
        else if (object_collided_with.CompareTag("Bow"))
        {
            //if (inventory != null)
            //{
            //    inventory.PickUpWeapon("Bow");
            //}

            //Debug.Log("Picked up bow!");
            Destroy(object_collided_with);
        }
        else if (object_collided_with.CompareTag("RestoreHealth"))
        {
            if (inventory != null)
            {
                inventory.RestoreHealth();
            }

            Debug.Log("restored health");
            Destroy(object_collided_with);


        }
        else if (object_collided_with.tag == "key"  && gameObject.name == "Player")
        {
            if (inventory != null)
            {
                inventory.AddKey(1);

            }
            AudioManager.instance.PlaySound(key_collection, transform.position);
            Debug.Log("Collected key!");
            Destroy(object_collided_with);
        }


    }
}
