using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wallmaster : MonoBehaviour
{
    public enum MoveDirection
    {
        Left,
        Right,
        Up,
        Down
    }

    [SerializeField] float movementSpeed = 2f;
    [SerializeField] float positionOffsetY = 1f;
    [SerializeField] float positionOffsetX = 0f;
    [SerializeField] float detectionDistance = 6f; // Maximum distance to detect the player
    [SerializeField] float moveDistance = 4f;
    [SerializeField] MoveDirection movementDirection;
    [SerializeField] Transform playerTransportTarget;
    private Player playerScript;

    [Header("Animations")]
    public float animationSpeed = 0.1f;
    public Sprite[] sprites;
    public Sprite closeSprite;
    private int currentSpriteIndex;

    [Header("Audio")]
    public AudioClip enemySound;
    private AudioSource audioSource; // Reference to AudioSource component

    private SpriteRenderer spriteRenderer;
    private Vector3 initialPosition;
    private Vector3 hidingPosition;
    private Vector3 endPosition;
    private Vector3 moveDirection;
    private bool isMoving = false;
    private bool isComingBack = false;
    private bool isComingOut = false;
    private bool isGrabbingPlayer = false;
    private GameObject player; // Reference to the player
    private float timer;
    void Start()
    {
        initialPosition = transform.position;
        hidingPosition = new Vector3(
            initialPosition.x + positionOffsetX, initialPosition.y + positionOffsetY, initialPosition.z);
        SetMoveDirection();

        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.enabled = false;

        audioSource = GetComponent<AudioSource>();

        IgnoreWallCollisions(true);
        IgnorePlayerCollisions(true);
    }

    // Update is called once per frame
    void Update()
    {
        UpdateAnimation();
    }

    private void FixedUpdate()
    {
        

        if (isMoving)
        {
            if (enemySound && !audioSource.isPlaying)
            {
                audioSource.clip = enemySound;
                audioSource.Play();
            }

            float distanceFromStart = Vector3.Distance(transform.position, initialPosition);
            Debug.Log("Distance from Start: " + distanceFromStart);
            if (distanceFromStart >= moveDistance)
            {
                StopAndReturn();
            }
        }

        if (!isMoving && !isComingBack && !isComingOut)
        {
            IgnorePlayerCollisions(true);
            CheckForPlayer();
        }
        else if (!isComingBack && !isComingOut)
        {
            transform.position += moveDirection * movementSpeed * Time.deltaTime;
        }
        else if (!isComingBack && isComingOut)
        {
            transform.position = Vector3.MoveTowards(
                transform.position, initialPosition, movementSpeed * Time.deltaTime);

            // Check if Wallmaster has reached initialPosition
            if (Vector3.Distance(transform.position, initialPosition) < 0.1f)
            {
                transform.position = initialPosition;
                isComingOut = false;
                isMoving = true;
            }
        }
        else if (isComingBack)
        {
            
            transform.position = Vector3.MoveTowards(
                transform.position, endPosition, movementSpeed * Time.deltaTime);

            // Check if Wallmaster has reached the end position
            if (Vector3.Distance(transform.position, endPosition) < 0.1f)
            {
                // Once back, hide the Wallmaster
                isComingBack = false;
                spriteRenderer.enabled = false; // Hide the sprite again
                transform.position = initialPosition;

                // Release the player at the designated transport location
                if (isGrabbingPlayer && player != null)
                {
                    IgnorePlayerCollisions(false);
                    playerScript.isGrabbed = false;
                    Camera.main.transform.position = CameraController.instance.initialPosition;
                    player.transform.position = playerTransportTarget.position;
                    GameController.player_control = true;
                    isGrabbingPlayer = false;
                    player = null;
                }

            }
        }

        // If grabbing player, move the player with the Wallmaster
        if (isGrabbingPlayer && player != null)
        {
            IgnorePlayerCollisions(true);
            playerScript.isGrabbed = true;
            player.transform.position = transform.position;
        }
        
    }

    void StopAndReturn()
    {
        isMoving = false; // Stop moving
        isComingBack = true;

        endPosition = new Vector3(
                transform.position.x + positionOffsetX,
                transform.position.y + positionOffsetY,
                transform.position.z);
    }

    void SetMoveDirection()
    {
        switch (movementDirection)
        {
            case MoveDirection.Left:
                moveDirection = Vector3.left; // Move left
                break;
            case MoveDirection.Right:
                moveDirection = Vector3.right; // Move right
                break;
            case MoveDirection.Up:
                moveDirection = Vector3.up; // Move up
                break;
            case MoveDirection.Down:
                moveDirection = Vector3.down; // Move down
                break;
        }
    }

    void CheckForPlayer()
    {
        if (RaycastForPlayer(moveDirection))
        {
            IgnorePlayerCollisions(false);
            BeginMovement();
            
        }
    }

    void BeginMovement()
    {
        spriteRenderer.enabled = true;
        transform.position = hidingPosition;
        isComingOut = true;
    }

    bool RaycastForPlayer(Vector3 direction)
    {
        RaycastHit hit;
        // Perform the raycast in the specified direction
        if (Physics.Raycast(transform.position, direction, out hit, detectionDistance))
        {
            // Check if the hit object is the player
            if (hit.collider.CompareTag("Player"))
            {
                Debug.Log($"Player detected in direction: {direction}");
                return true; // Player detected
            }
        }
        return false; // No player detected
    }

    void IgnoreWallCollisions(bool ignore)
    {
        // Find all wall GameObjects by the tag "Wall"
        GameObject[] wallObjects = GameObject.FindGameObjectsWithTag("Wall");

        foreach (GameObject wall in wallObjects)
        {
            Collider wallCollider = wall.GetComponent<Collider>();
            if (wallCollider != null)
            {
                // Ignore or re-enable collisions between the Wallmaster and each wall collider
                Physics.IgnoreCollision(GetComponent<Collider>(), wallCollider, ignore);
            }
        }
    }

    void IgnorePlayerCollisions(bool ignore)
    {
        // Find all wall GameObjects by the tag "Wall"
        GameObject player = GameObject.FindGameObjectWithTag("Player");

        Collider playerCollider = player.GetComponent<Collider>();
        if (player != null)
        {
            // Ignore or re-enable collisions between the Wallmaster and each wall collider
            Physics.IgnoreCollision(GetComponent<Collider>(), playerCollider, ignore);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // Detect collision with the player
        if (other.CompareTag("Player") && !isComingBack && !isGrabbingPlayer)
        {
            player = other.gameObject; // Reference the player object
            playerScript = player.GetComponent<Player>();
            if (playerScript != null && !playerScript.isGrabbed)
            {
                isGrabbingPlayer = true; // Flag to start moving the player with the Wallmaster
                GameController.player_control = false;
            }
            
        }
    }

    void UpdateAnimation()
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            currentSpriteIndex = (currentSpriteIndex + 1) % 2;
            if (!isGrabbingPlayer) spriteRenderer.sprite = sprites[currentSpriteIndex];
            else spriteRenderer.sprite = closeSprite;

        }
    }
}
