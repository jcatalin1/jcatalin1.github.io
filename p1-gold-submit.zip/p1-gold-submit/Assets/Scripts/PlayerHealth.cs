using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 3;
    public int currentHealth;
    public SpriteRenderer spriteRenderer;
    public Color hitColor = Color.red;
    public float flashDuration = 0.1f;
    public float flashInterval = 0.1f;
    public float knockbackForce = 9f;
    public float hitStunDuration = 0.2f;
    public float invincibilityDuration = 1f;
    private bool isHitStunned;
    private bool isInvincible;
    private Rigidbody rb;
    private ArrowKeyMovement movementScript;

    public AudioClip damageSound;
    public AudioClip deathSound;
    public AudioClip lowHealthSound; 
    private AudioSource audioSource;
    private AudioSource lowHealthAudioSource;

    void Start()
    {
        currentHealth = maxHealth;
        isHitStunned = false;
        isInvincible = false;
        rb = GetComponent<Rigidbody>();
        movementScript = GetComponent<ArrowKeyMovement>();
        audioSource = GetComponent<AudioSource>();

        if (rb == null)
        {
            Debug.LogError("Rigidbody component is missing on the player!");
        }

        if (audioSource == null)
        {
            Debug.LogError("AudioSource component is missing on the player!");
        }

        lowHealthAudioSource = gameObject.AddComponent<AudioSource>();
        lowHealthAudioSource.clip = lowHealthSound;
        lowHealthAudioSource.loop = true; 
    }

    public void TakeDamage(int damage, Vector3 knockbackDirection)
    {
        if (CheatCodeManager.god_mode) return;
        if (isInvincible || isHitStunned) return; 

        currentHealth -= damage;

        if (damageSound != null)
        {
            AudioSource.PlayClipAtPoint(damageSound, transform.position);
        }


        HandleLowHealthSound();

        if (currentHealth <= 0)
        {
            currentHealth = 0;
            StartCoroutine(Die());
        }
        else
        {
            StartCoroutine(HitStunCoroutine(knockbackDirection));
            StartCoroutine(InvincibilityCoroutine());
        }
    }

    private void HandleLowHealthSound()
    {
        if (currentHealth == 1)
        {
            if (!lowHealthAudioSource.isPlaying)
            {
                lowHealthAudioSource.Play(); 
            }
        }
        else
        {
            if (lowHealthAudioSource.isPlaying)
            {
                lowHealthAudioSource.Stop(); 
            }
        }
    }

    IEnumerator Die()
    {
        if (deathSound != null)
        {
            AudioSource.PlayClipAtPoint(deathSound, transform.position);
        }

        Time.timeScale = 0f;

        yield return new WaitForSecondsRealtime(4f);

        Time.timeScale = 1f; // reset game time back to normal
        Debug.Log("Player has died. Restarting the game...");
        ShapeshiftController shapeshiftController = GetComponent<ShapeshiftController>();
        if (shapeshiftController) shapeshiftController.RevertToPlayer();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    IEnumerator HitStunCoroutine(Vector3 knockbackDirection)
    {
        isHitStunned = true;
        movementScript.isKnockedBack = true;
        StartCoroutine(FlashEffectCoroutine());

        Vector3 knockbackDirectionTemp;
        if (Mathf.Abs(knockbackDirection.x) > Mathf.Abs(knockbackDirection.y))
        {
            knockbackDirectionTemp = knockbackDirection.x > 0 ? new Vector3(1, 0, 0) : new Vector3(-1, 0, 0);
            Debug.Log("Horizontal knockback: " + knockbackDirectionTemp);
        }
        else
        {
            knockbackDirectionTemp = knockbackDirection.y > 0 ? new Vector3(0, 1, 0) : new Vector3(0, -1, 0);
            Debug.Log("Vertical knockback: " + knockbackDirectionTemp);
        }

        if (rb != null)
        {
            rb.velocity = Vector3.zero; 
            knockbackForce = 45f; 
            Vector3 force = knockbackDirectionTemp * knockbackForce; 
            Debug.Log($"Knockback applied. Direction: {knockbackDirectionTemp}, Force: {force}");

            rb.AddForce(force, ForceMode.Impulse);

            Collider playerCollider = GetComponent<Collider>();
            if (playerCollider != null)
            {
                playerCollider.enabled = false;
            }

            movementScript.isKnockedBack = true;
        }


        yield return new WaitForSeconds(0.3f);


        if (rb != null)
        {
            rb.velocity = Vector3.zero; // Reset velocity
            Collider playerCollider = GetComponent<Collider>();
            if (playerCollider != null)
            {
                playerCollider.enabled = true; // Re-enable collider
            }
        }

        movementScript.isKnockedBack = false;
        isHitStunned = false;
    }


    IEnumerator InvincibilityCoroutine()
    {
        isInvincible = true;
        yield return new WaitForSeconds(invincibilityDuration);
        isInvincible = false;
    }

    IEnumerator FlashEffectCoroutine()
    {
        float elapsed = 0f;
        bool isFlashOn = true;
        while (elapsed < invincibilityDuration)
        {
            elapsed += flashInterval;
            spriteRenderer.color = isFlashOn ? hitColor : Color.white;
            isFlashOn = !isFlashOn;
            yield return new WaitForSeconds(flashInterval);
        }
        spriteRenderer.color = Color.white;
    }

    public void Heal(int amount)
    {
        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        Debug.Log("Player healed. Current health: " + currentHealth);

        HandleLowHealthSound();
    }

    public int GetCurrentHealth()
    {
        return currentHealth;
    }

    public bool IsFullHealth()
    {
        return currentHealth == maxHealth;
    }
}
