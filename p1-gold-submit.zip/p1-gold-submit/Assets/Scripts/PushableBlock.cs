using UnityEngine;

public class PushableBlock : MonoBehaviour
{
    public float pushDuration = 1.0f;  // time the player needs to push before the block moves
    public float moveDistance = 1.0f;  // distance the block moves 
    public float moveSpeed = 2.0f;     // speed at which the block moves
    public float gridSize = 1.0f;      // size of each grid cell

    private bool isBeingPushed = false;
    private float pushTimer = 0.0f;
    private Vector3 pushDirection;
    private Vector3 targetPosition;
    private bool isMoving = false;
    private Rigidbody rb;


    private void OnCollisionStay(Collision other)
    {
        if (other.collider.CompareTag("Player"))
        {
            Vector3 playerDirection = GetRoundedDirection(other.transform.position - transform.position);

            if (IsPushingBlock(playerDirection) && !isMoving)
            {
                if (!isBeingPushed)
                {
                    isBeingPushed = true;
                    pushDirection = playerDirection;
                }

                pushTimer += Time.deltaTime;

                if (pushTimer >= pushDuration)
                {
                    MoveBlock(-pushDirection);
                    pushTimer = 0.0f;
                    isBeingPushed = false;
                }
            }

            MovePlayerBack(other.collider, playerDirection);
        }
    }

    private void MovePlayerBack(Collider playerCollider, Vector3 pushDirection)
    {
        Rigidbody playerRb = playerCollider.GetComponent<Rigidbody>();
        if (playerRb != null)
        {
            Vector3 moveBack = pushDirection * 0.3f;  // move player back by 0.3units, kinda an easy way out but will review? 
            playerRb.MovePosition(playerCollider.transform.position + moveBack);
        }
    }


    private void OnCollisionExit(Collision other)
    {
        if (other.collider.CompareTag("Player"))
        {
            ResetPush();
        }
    }

    private void ResetPush()
    {
        isBeingPushed = false;
        pushTimer = 0.0f;
    }

    private bool IsPushingBlock(Vector3 playerDirection)
    {
        bool validDirection = (Mathf.Abs(playerDirection.x) == 1 && playerDirection.y == 0) ||
                              (Mathf.Abs(playerDirection.y) == 1 && playerDirection.x == 0);
        return validDirection;
    }

    private Vector3 GetRoundedDirection(Vector3 direction)
    {
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
        {
            direction.x = Mathf.Sign(direction.x);
            direction.y = 0;
        }
        else
        {
            direction.y = Mathf.Sign(direction.y);
            direction.x = 0;
        }
        return direction;
    }

    private void MoveBlock(Vector3 direction)
    {
        targetPosition = transform.position + new Vector3(direction.x * gridSize, direction.y * gridSize, 0);
        if (!IsObstacleInDirection(direction))
        {
            Debug.Log($"Block is moving towards {targetPosition}");
            isMoving = true;
        }
        else
        {
            Debug.Log("Block cannot move, obstacle detected.");
        }
    }

    private bool IsObstacleInDirection(Vector3 direction)
    {
        Vector3 origin = transform.position + (direction * 0.1f);
        RaycastHit hit;

        Debug.DrawRay(origin, direction * gridSize, Color.red, 1.0f);

        if (Physics.Raycast(origin, direction, out hit, gridSize))
        {
            Debug.Log($"Raycast hit: {hit.collider.name}, Tag: {hit.collider.tag}");

            if (hit.collider.CompareTag("Wall") || hit.collider.CompareTag("Block") || hit.collider.CompareTag("InvisibleBlock"))
            {
                return true;  // obstacle detected
            }
        }

        return false;  
    }

    private void Update()
    {
        if (isMoving)
        {
            MoveToPosition(targetPosition);
        }
    }

    private void MoveToPosition(Vector3 targetPosition)
    {
        float step = moveSpeed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);

        if (Vector3.Distance(transform.position, targetPosition) < 0.01f)
        {
            transform.position = targetPosition;
            isMoving = false;
        }
    }
}
