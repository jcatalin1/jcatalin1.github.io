using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : MonoBehaviour
{
    public float speed = 10f;
    public float damage = 1f;
    public SpriteRenderer spriteRenderer;

    public Sprite upSprite;
    public Sprite downSprite;
    public Sprite leftSprite;
    public Sprite rightSprite;

    public GameObject colliderObject; 

    private Vector3 direction;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();

        if (colliderObject != null)
        {
            ArrowColliderHandler colliderHandler = colliderObject.GetComponent<ArrowColliderHandler>();
            if (colliderHandler != null)
            {
                colliderHandler.Initialize(this);
            }
            else
            {
                Debug.LogError("Collider object is missing the ArrowColliderHandler script.");
            }
        }
        else
        {
            Debug.LogError("Collider object is not assigned.");
        }

        Destroy(gameObject, 3f);
    }


    public void Initialize(Vector3 dir)
    {
        direction = dir;

        if (dir == Vector3.up)
        {
            spriteRenderer.sprite = upSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 0);
        }
        else if (dir == Vector3.down)
        {
            spriteRenderer.sprite = downSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 180);
        }
        else if (dir == Vector3.left)
        {
            spriteRenderer.sprite = leftSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, 90);
        }
        else if (dir == Vector3.right)
        {
            spriteRenderer.sprite = rightSprite;
            colliderObject.transform.localRotation = Quaternion.Euler(0, 0, -90);
        }
    }


    void Update()
    {
        transform.Translate(direction * speed * Time.deltaTime);
        Debug.Log("Arrow position: " + transform.position);
    }


    public void HandleCollision(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            Enemy enemy = other.GetComponent<Enemy>();
            if (enemy != null)
            {
                Vector3 knockbackDirection = (other.transform.position - transform.position).normalized;
                enemy.TakeDamage((int)damage, knockbackDirection);
            }
            Destroy(gameObject); 
        }
        else if (other.CompareTag("Wall"))
        {
            Destroy(gameObject); 
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        HandleCollision(other);
    }
}
