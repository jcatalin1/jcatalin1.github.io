using UnityEngine;
using UnityEngine.UI;

public class ShapeshiftController : MonoBehaviour
{
    private EnemyType.Type collectedSoulType;
    private bool hasCollectedSoul = false;
    private bool isInSoulForm = false; 

    public SpriteRenderer playerSpriteRenderer;
    private Sprite originalPlayerSprite;

    private ArrowKeyMovement arrowKeyMovement;

    public Image shapeshiftStatusUI;
    public Text shapeshiftStatusText; 

    void Start()
    {
        arrowKeyMovement = GetComponent<ArrowKeyMovement>();
        originalPlayerSprite = playerSpriteRenderer.sprite;
        UpdateShapeshiftUI(); 
    }

    void Update()
    {

        if (Input.GetKeyDown(KeyCode.J))
        {
            if (isInSoulForm && hasCollectedSoul)
            {
                RevertToPlayer(); 
            }
            else if (hasCollectedSoul && PlayerState.IsPlayer()) // Check if player can transform
            {
                TransformIntoEnemy(collectedSoulType); // Turn into soul form if soul collected
            }
        }
        UpdateShapeshiftUI();
    }


    public void CollectSoul(EnemyType.Type soulType)
    {
        if (!hasCollectedSoul) // Check if a soul is already collected
        {
            hasCollectedSoul = true;
            collectedSoulType = soulType; // Store the collected soul type
            UpdateShapeshiftUI(); // Update the UI to reflect soul collection
        }
        else
        {
            Debug.Log("Already holding a soul. Cannot collect another.");
        }
    }

    public void TransformIntoEnemy(EnemyType.Type enemyType)
    {
        // If already in soul form, return without transforming
        if (isInSoulForm) return;

        isInSoulForm = true; // Now in soul form
        hasCollectedSoul = false; // Consume the soul on transformation

        switch (enemyType)
        {
            case EnemyType.Type.Keese:
                KeeseTransformation keeseTransformation = GetComponent<KeeseTransformation>();
                if (keeseTransformation != null)
                {
                    keeseTransformation.TransformToKeese();
                    Debug.Log("Transformed into Keese!");
                }
                else
                {
                    Debug.LogError("KeeseTransformation script not found on the player!");
                }
                break;

            case EnemyType.Type.Stalfos:
                StalfosTransformation stalfosTransformation = GetComponent<StalfosTransformation>();
                if (stalfosTransformation != null)
                {
                    stalfosTransformation.TransformToStalfos();
                    Debug.Log("Transformed into Stalfos!");
                }
                else
                {
                    Debug.LogError("StalfosTransformation script not found on the player!");
                }
                break;

            case EnemyType.Type.Aquamentus:
                PlayerState.TransformToEnemy(PlayerState.State.Aquamentus);
                Debug.Log("Transformed into Aquamentus!");
                break;

            case EnemyType.Type.Gel:
                GelTransformation gelTransformation = GetComponent<GelTransformation>();
                if (gelTransformation != null)
                {
                    gelTransformation.TransformToGel();
                    Debug.Log("Transformed into Gel!");
                }
                else
                {
                    Debug.LogError("GelTransformation script not found on the player!");
                }
                break;

            case EnemyType.Type.Goriya:
                GoriyaTransformation goriyaTransformation = GetComponent<GoriyaTransformation>();
                if (goriyaTransformation != null)
                {
                    goriyaTransformation.TransformToGoriya();
                    Debug.Log("Transformed into Goriya!");
                }
                else
                {
                    Debug.LogError("GoriyaTransformation script not found on the player!");
                }
                break;
        }

        UpdateShapeshiftUI(); 
    }

    public void RevertToPlayer()
    {
        isInSoulForm = false; // Return to player form
        hasCollectedSoul = false; // Consume the soul on transformation
        playerSpriteRenderer.flipX = false;
        if (PlayerState.IsStalfos())
        {
            PlayerState.RevertToPlayer();
            playerSpriteRenderer.sprite = originalPlayerSprite;

            if (arrowKeyMovement != null)
            {
                arrowKeyMovement.isStalfos = false;
            }

            transform.localScale = new Vector3(1f, 1f, 1f);
            Debug.Log("Reverted to normal player form from Stalfos");

        }
        else if (PlayerState.IsGel())
        {
            PlayerState.RevertToPlayer();
            playerSpriteRenderer.sprite = originalPlayerSprite;

            if (arrowKeyMovement != null)
            {
                arrowKeyMovement.isGel = false;
                arrowKeyMovement.enableArrowKeys = true;
                arrowKeyMovement.enableWASD = true;
            }

            GameObject gelClone = GameObject.Find("Player(Clone)");
            if (gelClone != null)
            {
                Destroy(gelClone);
                Debug.Log("Gel clone destroyed.");
            }

            transform.localScale = new Vector3(1f, 1f, 1f);
        }
        else if (PlayerState.IsGoriya())
        {
            PlayerState.RevertToPlayer();
            playerSpriteRenderer.sprite = originalPlayerSprite;

            if (arrowKeyMovement != null)
            {
                arrowKeyMovement.isGoriya = false;
            }

            transform.localScale = new Vector3(1f, 1f, 1f);
            Debug.Log("Reverted to normal player form from Goriya");
        }
        else if (PlayerState.IsKeese())
        {
            PlayerState.RevertToPlayer();
            playerSpriteRenderer.sprite = originalPlayerSprite;

            if (arrowKeyMovement != null)
            {
                arrowKeyMovement.isKeese = false;
            }

            arrowKeyMovement.spriteRenderer.sprite = arrowKeyMovement.originalSprite;
            arrowKeyMovement.upSprites = arrowKeyMovement.originalUpSprites;
            arrowKeyMovement.downSprites = arrowKeyMovement.originalDownSprites;
            arrowKeyMovement.leftSprites = arrowKeyMovement.originalLeftSprites;
            arrowKeyMovement.rightSprites = arrowKeyMovement.originalRightSprites;

            transform.localScale = new Vector3(1f, 1f, 1f);

            Debug.Log("Reverted to normal player form from Keese");
        }
    }

    private void UpdateShapeshiftUI()
    {
        if (hasCollectedSoul && !isInSoulForm)
        {

            switch (collectedSoulType)
            {
                case EnemyType.Type.Keese:
                    shapeshiftStatusUI.color = HexToColor("525252"); 
                    shapeshiftStatusText.text = "for Keese";
                    break;
                case EnemyType.Type.Stalfos:
                    shapeshiftStatusUI.color = HexToColor("B9191B"); 
                    shapeshiftStatusText.text = "for Stalfos";
                    break;
                case EnemyType.Type.Gel:
                    shapeshiftStatusUI.color = HexToColor("00A5FF"); 
                    shapeshiftStatusText.text = "for Gel";
                    break;
                case EnemyType.Type.Goriya:
                    shapeshiftStatusUI.color = HexToColor("E2773B"); 
                    shapeshiftStatusText.text = "for Goriya";
                    break;

            }
        }
        else if (isInSoulForm && hasCollectedSoul)
        {
            shapeshiftStatusUI.color = Color.green; // Green for Link in soul form
            shapeshiftStatusText.text = "for Link";
        }
        else if(isInSoulForm)
        {
            shapeshiftStatusUI.color = Color.white; // white when no soul is collected
            shapeshiftStatusText.text = "for Link";
        }
        else
        {
            shapeshiftStatusUI.color = Color.white; // white when no soul is collected
            shapeshiftStatusText.text = "No Soul";
        }
    }


    private Color HexToColor(string hex)
    {


        // Parse the hex string into a Color object
        if (hex.Length == 6) // RGB
        {
            byte r = (byte)(int.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber));
            byte g = (byte)(int.Parse(hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber));
            byte b = (byte)(int.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber));
            return new Color32(r, g, b, 255); // Set alpha to 255 (opaque)
        }
        else if (hex.Length == 8) // RGBA
        {
            byte r = (byte)(int.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber));
            byte g = (byte)(int.Parse(hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber));
            byte b = (byte)(int.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber));
            byte a = (byte)(int.Parse(hex.Substring(6, 2), System.Globalization.NumberStyles.HexNumber));
            return new Color32(r, g, b, a);
        }

        // Default color if input is not valid
        return Color.white;
    }


}
