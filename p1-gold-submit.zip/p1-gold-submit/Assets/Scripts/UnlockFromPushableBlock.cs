using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnlockFromPushableBlock : MonoBehaviour
{
    public GameObject keyDoor;
    public Sprite unlockedDoorSprite;
    public AudioClip unlockSound;  // Add this to store the sound

    private SpriteRenderer spriteRenderer;
    public BoxCollider boxCollider;

    void Start()
    {
        spriteRenderer = keyDoor.GetComponent<SpriteRenderer>();
        if (spriteRenderer == null)
        {
            Debug.LogWarning("KeyDoor does not have a SpriteRenderer component.");
        }

        boxCollider = keyDoor.GetComponent<BoxCollider>();
        if (boxCollider == null)
        {
            Debug.LogWarning("KeyDoor does not have a BoxCollider component.");
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("PushableBlock"))
        {
            UnlockDoor(other);
        }
    }

    private void UnlockDoor(Collider other)
    {
        // Change the door sprite to the unlocked version
        if (spriteRenderer && unlockedDoorSprite)
        {
            spriteRenderer.sprite = unlockedDoorSprite;
            Debug.Log("Door sprite changed to unlocked.");
        }


        // Play unlock sound (if assigned)
        if (unlockSound != null)
        {
            AudioSource.PlayClipAtPoint(unlockSound, transform.position);
        }

        StartCoroutine(DisableDoorCollider());
    }

    private IEnumerator DisableDoorCollider()
    {
        yield return new WaitForSeconds(1f);

        if (boxCollider)
        {
            boxCollider.enabled = false;
            Debug.Log("Door collider disabled.");
        }
    }
}
