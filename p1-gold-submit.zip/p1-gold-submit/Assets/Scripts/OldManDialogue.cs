using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class OldManDialogue : MonoBehaviour
{
    public GameObject dialogueBox;           // UI dialogue box
    public Text dialogueText;                // Text component for the dialogue
    public string dialogue = "The eastmost peninsula is the secret.";  // Dialogue to display
    public GameObject oldMan;                // Old Man game object
    public GameObject fire1;                 // First fire object
    public GameObject fire2;                 // Second fire object
    public GameObject door;                  // Door object (that opens/closes)
    public Transform previousRoomPosition;   // The specific position to move the player to
    public Vector3 cameraShift;              // The camera shift for moving between rooms

    public Sprite lockedDoorSprite;          // The sprite for the locked door
    private SpriteRenderer doorSpriteRenderer; // The SpriteRenderer component of the door

    private bool dialogueStarted = false;
    private bool doorOpened = false;

    void Start()
    {
        // Get the SpriteRenderer component of the door
        doorSpriteRenderer = door.GetComponent<SpriteRenderer>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !dialogueStarted)
        {
            dialogueStarted = true;
            StartCoroutine(DisplayDialogue(other));
        }
    }

    private IEnumerator DisplayDialogue(Collider player)
    {
        // Show the dialogue box and gradually reveal the text
        dialogueBox.SetActive(true);
        dialogueText.text = "";

        foreach (char letter in dialogue.ToCharArray())
        {
            dialogueText.text += letter;
            yield return new WaitForSeconds(0.05f);  // Adjust delay for effect
        }

        yield return new WaitForSeconds(3f);  // Dialogue delay

        // Hide the dialogue box and remove the Old Man and fires
        dialogueBox.SetActive(false);
        oldMan.SetActive(false);
        fire1.SetActive(false);
        fire2.SetActive(false);

        // Open the door and allow the player to leave
        OpenDoor();

        yield return new WaitForSeconds(1f);  // Optional delay before transition

        // Move the player and shift the camera to the next room
        MovePlayerToPreviousRoom(player);

        dialogueStarted = false;
    }

    private void OpenDoor()
    {
        if (!doorOpened)
        {
            door.SetActive(false);  // Simulating door opening by deactivating it
            doorOpened = true;
        }
    }

    private void CloseDoor()
    {
        door.SetActive(true);  // Simulating door closing by activating it
        doorOpened = false;

        // Change the door sprite to the locked door sprite
        doorSpriteRenderer.sprite = lockedDoorSprite; // Set the door sprite to locked
    }

    private void MovePlayerToPreviousRoom(Collider player)
    {
        // Move the player to the specific position in the previous room
        player.transform.position = previousRoomPosition.position;

        // Trigger the camera to start moving using the existing camera shift logic
        CameraController.instance.StartRoomTransition(cameraShift, Vector3.zero);

        // Re-enable player collisions after moving
        player.gameObject.GetComponent<Collider>().enabled = true;

        // Lock the door again after the transition
        CloseDoor();
    }
}
