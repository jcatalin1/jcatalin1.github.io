using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance;

    private void Awake()
    {
        // Singleton pattern implementation
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Keep the AudioManager alive across scenes
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Method to play sound effects
    public void PlaySound(AudioClip clip, Vector3 position)
    {
        if (clip != null)
        {
            AudioSource.PlayClipAtPoint(clip, position);
        }
    }
    public void PlayMusic(AudioClip clip, float volume = 1.0f)
    {
        // You can have an AudioSource component on the AudioManager GameObject for music
        AudioSource audioSource = GetComponent<AudioSource>();
        if (audioSource != null && clip != null)
        {
            audioSource.clip = clip;
            audioSource.volume = volume;
            audioSource.loop = true;
            audioSource.Play();
        }
    }
}
