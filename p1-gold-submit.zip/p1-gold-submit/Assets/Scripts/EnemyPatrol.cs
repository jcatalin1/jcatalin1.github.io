using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol : MonoBehaviour
{
    // Sprite Stuff
    public Sprite[] moveSprites;
    public Sprite waitSprite;
    public float animationSpeed = 0.1f;
    private SpriteRenderer spriteRenderer;
    private float timer;
    private int currentSpriteIndex;

    public Transform[] patrolPoints; // Array of patrol points the enemy will move to
    public float maxSpeed = 4f; // Maximum speed of the enemy while patrolling
    public float minSpeed = 1f; // Minimum speed when approaching the target
    public float constSpeed = 4f;
    public float waitTimeAtPoint = 1f; // Base time to wait at each patrol point
    public float noWaitChance = 0.3f; // Probability (0-1) that the Keese will not wait at a patrol point
    private int currentPointIndex = 0; // Current patrol point index
    private bool isWaiting = false; // Flag to indicate if the enemy is waiting at a point
    private bool shouldFluctuate = true; // Flag to determine if speed should fluctuate

    private Rigidbody rb;
    private float totalDistance; // Total distance to the target
    private Collider keeseCollider; // Reference to the Keese's collider
    private Vector3 initialPos;

    void Start()
    {
        Debug.Log("Initial position: " + initialPos);
        InitializeKeese();
    }

    void OnEnable()
    {
        // Ensure movement and patrol logic starts again when the Keese is re-enabled
        
        InitializeKeese();
    }

    void OnDisable()
    {
        // Stop all coroutines when the enemy is deactivated
        StopAllCoroutines();
    }

    private void InitializeKeese()
    {
        Debug.Log("Start Keese");
        
        // Initialize SpriteRenderer
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.sprite = waitSprite;

        // Initialize Rigidbody
        rb = GetComponent<Rigidbody>();
        keeseCollider = GetComponent<Collider>();

        // Initialize current point index
        currentPointIndex = Random.Range(0, patrolPoints.Length);

        // Initialize total distance for the first target
        totalDistance = Vector3.Distance(transform.position, patrolPoints[currentPointIndex].position);

        // Start the patrol coroutine
        StopAllCoroutines();
        StartCoroutine(InitialWaitAndStartPatrol());
    }


    private void Update()
    {
        if (!isWaiting)
        {
            UpdateAnimation();
        }
    }

    IEnumerator InitialWaitAndStartPatrol()
    {
        Debug.Log("Waiting 1 sec");
        // Initial wait for 1 second before starting the patrol
        yield return new WaitForSeconds(waitTimeAtPoint);
        Debug.Log("Starting Patrol");
        // Start the patrol coroutine
        StartCoroutine(PatrolRoutine());
    }

    IEnumerator PatrolRoutine()
    {
        while (true) // Infinite loop for continuous patrol
        {
            if (!isWaiting)
            {
                // Move towards the current patrol point
                Vector3 targetPosition = patrolPoints[currentPointIndex].position;
                Vector3 direction = (targetPosition - transform.position).normalized;

                // Calculate speed based on distance or use maxSpeed if no fluctuation is needed
                float distanceToTarget = Vector3.Distance(transform.position, targetPosition);
                float fluctuatingSpeed = shouldFluctuate ? 
                    CalculateSpeedBasedOnProgress(distanceToTarget) : constSpeed;

                // Remove collisions while moving
                IgnoreWallCollisions(true);
                // Move enemy with fluctuating or constant speed
                rb.MovePosition(transform.position + direction * fluctuatingSpeed * Time.deltaTime);

                // Check if the enemy has reached the patrol point
                if (distanceToTarget < 0.1f)
                {
                    //Re-enable wall collisions
                    IgnoreWallCollisions(false);

                    // Determine randomly whether to wait or move immediately
                    if (Random.value < noWaitChance)
                    {
                        // Move to the next patrol point without waiting
                        currentPointIndex = GetNextPointIndex();
                        totalDistance = Vector3.Distance(transform.position, patrolPoints[currentPointIndex].position);
                        shouldFluctuate = false; // Set flag to false to keep speed constant
                    }
                    else
                    {
                        // Wait at the patrol point
                        isWaiting = true;
                        spriteRenderer.sprite = waitSprite;
                        yield return new WaitForSeconds(waitTimeAtPoint);
                        isWaiting = false;

                        // Move to the next patrol point randomly
                        currentPointIndex = GetNextPointIndex();
                        totalDistance = Vector3.Distance(transform.position, patrolPoints[currentPointIndex].position);
                        shouldFluctuate = true; // Set flag to true to allow speed fluctuation
                    }
                }
            }

            yield return null; // Wait for the next frame
        }
    }

    int GetNextPointIndex()
    {
        int newIndex;
        do
        {
            newIndex = Random.Range(0, patrolPoints.Length);
        } while (newIndex == currentPointIndex); // Ensure it's different from the current index

        return newIndex;
    }

    // Function to calculate speed based on progress towards the target
    float CalculateSpeedBasedOnProgress(float distanceToTarget)
    {
        // Calculate the progress from the start point to the target point
        float progress = 1f - (distanceToTarget / totalDistance); // Progress from 0 (start) to 1 (end)

        // Use a quadratic function to accelerate and decelerate
        float speed = Mathf.Lerp(minSpeed, maxSpeed, progress * (1 - progress));

        return speed;
    }

    // Function to ignore collisions with walls by finding GameObjects with the "Wall" tag
    void IgnoreWallCollisions(bool ignore)
    {
        // Find all wall GameObjects by the tag "Wall"
        GameObject[] wallObjects = GameObject.FindGameObjectsWithTag("Wall");

        foreach (GameObject wall in wallObjects)
        {
            Collider wallCollider = wall.GetComponent<Collider>();
            if (wallCollider != null)
            {
                // Ignore or re-enable collisions between the Keese and each wall collider
                Physics.IgnoreCollision(keeseCollider, wallCollider, ignore);
            }
        }
    }

    void UpdateAnimation()
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            currentSpriteIndex = (currentSpriteIndex + 1) % 4; // Switch between sprites
            spriteRenderer.sprite = moveSprites[currentSpriteIndex];
        }
    }
}
