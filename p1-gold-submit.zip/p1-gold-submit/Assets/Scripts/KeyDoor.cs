using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyDoor : MonoBehaviour
{
    public GameObject player;
    public GameObject keyDoor;
    public GameObject adjKeyDoor;
    public Sprite unlockedDoorSprite; // Sprite to show when the door is unlocked
    public Sprite adjUnlockedDoorSprite;

    private Inventory inventory;
    private SpriteRenderer spriteRenderer;
    private BoxCollider boxCollider;

    private SpriteRenderer adjSpriteRenderer;
    private BoxCollider adjBoxCollider;


    void Start()
    {
        inventory = player.GetComponent<Inventory>();
        if (inventory == null)
        {
            Debug.LogWarning("player does not have an inventory object");
        }

        // Get the SpriteRenderer component of the door
        spriteRenderer = keyDoor.GetComponent<SpriteRenderer>();
        if (spriteRenderer == null)
        {
            Debug.LogWarning("KeyDoor does not have a SpriteRenderer component.");
        }

        // Get the BoxCollider component of the door
        boxCollider = keyDoor.GetComponent<BoxCollider>();
        if (boxCollider == null)
        {
            Debug.LogWarning("KeyDoor does not have a BoxCollider component.");
        }

        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player" && other.gameObject.name == "Player" && inventory.GetKeys() > 0)
        {
            Debug.Log("Unlocked Door with Key");
            inventory.RemoveKey();

            // Change the door sprite to the unlocked door sprite
            if (spriteRenderer && unlockedDoorSprite)
            {
                spriteRenderer.sprite = unlockedDoorSprite;
            }

            // Disable the door's collider to allow the player to pass through
            if (boxCollider)
            {
                boxCollider.enabled = false;
            }

            // If adjacent door object needs to be changed
            if (adjKeyDoor)
            {
                adjSpriteRenderer = adjKeyDoor.GetComponent<SpriteRenderer>();
                adjBoxCollider = adjKeyDoor.GetComponent<BoxCollider>();

                if (adjSpriteRenderer && adjUnlockedDoorSprite)
                {
                    adjSpriteRenderer.sprite = adjUnlockedDoorSprite;
                }

                if (adjBoxCollider)
                {
                    adjBoxCollider.enabled = false;
                }

            }
        }
    }

    public void Unlock()
    {
        // Change the door sprite to the unlocked door sprite
        if (spriteRenderer && unlockedDoorSprite)
        {
            spriteRenderer.sprite = unlockedDoorSprite;
        }

        // Disable the door's collider to allow the player to pass through
        if (boxCollider)
        {
            boxCollider.enabled = false;
        }

        // If adjacent door object needs to be changed
        if (adjKeyDoor)
        {
            adjSpriteRenderer = adjKeyDoor.GetComponent<SpriteRenderer>();
            adjBoxCollider = adjKeyDoor.GetComponent<BoxCollider>();

            if (adjSpriteRenderer && adjUnlockedDoorSprite)
            {
                adjSpriteRenderer.sprite = adjUnlockedDoorSprite;
            }

            if (adjBoxCollider)
            {
                adjBoxCollider.enabled = false;
            }
        }
    }

}
