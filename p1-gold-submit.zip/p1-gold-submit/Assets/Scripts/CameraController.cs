using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public static CameraController instance;

    public GameObject player;

    public Vector3 initialPosition;

    private bool isTransitioning = false;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        initialPosition = transform.position;
    }

    public void StartRoomTransition(Vector3 cameraShift, Vector3 playerShift)
    {
        if (!isTransitioning)
        {
            StartCoroutine(RoomTransition(cameraShift, playerShift));
        }
    }

    public void StartRoomTransitionInstant(Vector3 cameraShift, Vector3 playerShift)
    {
        if (!isTransitioning)
        {
            RoomTransitionInstant(cameraShift, playerShift);
        }
    }

    public bool IsTransitioning()
    {
        return isTransitioning;
    }

    IEnumerator RoomTransition(Vector3 cameraShift, Vector3 playerShift)
    {
        isTransitioning = true; // Prevent multiple transitions at the same time
        GameController.player_control = false;

        Vector3 initial_position = transform.position;
        Vector3 final_position = initial_position + cameraShift;

        /* Transition to new "room" */
        yield return StartCoroutine(
            //add an option to not move it over time if a bool is checked in door trigger 
            CoroutineUtilities.MoveObjectOverTime(transform, initial_position, final_position, 2.5f)
        );

        /* Move player to other room */
        player.transform.position += playerShift;
        //ifGel
        GameObject gelClone = GameObject.Find("Player(Clone)");
        if (gelClone != null)
        {
            Vector3 clonePosition = player.transform.position;
            clonePosition.y -= 1;
            gelClone.transform.position = clonePosition;

        }

        // enable player collisions
        player.GetComponent<Collider>().enabled = true;

        GameController.player_control = true;
        isTransitioning = false; // Allow new transitions after completing
    }

    public void RoomTransitionInstant(Vector3 cameraShift, Vector3 playerShift)
    {
        isTransitioning = true; // Prevent multiple transitions at the same time
        GameController.player_control = false;

        Vector3 initial_position = transform.position;
        Vector3 final_position = initial_position + cameraShift;

        transform.position = final_position;

        //move object instantly

        /* Move player to other room */
        player.transform.position += playerShift;

        // enable player collisions
        player.GetComponent<Collider>().enabled = true;

        GameController.player_control = true;
        isTransitioning = false; // Allow new transitions after completing
    }
}