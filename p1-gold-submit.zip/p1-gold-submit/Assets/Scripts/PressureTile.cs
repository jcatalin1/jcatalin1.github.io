using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PressureTile : MonoBehaviour
{
    [Header("Tile Settings")]
    public PressureTile otherTile;  // Reference to the other tile object
    public GameObject keyPrefab;  // The key prefab to spawn
    public Transform keySpawnPosition;  // The position where the key will spawn

    [Header("Tile Color")]
    public Color pressedColor = Color.red;

    public int playersOnTile = 0;  // Track how many players are standing on this tile
    private bool keySpawned = false;  // Keep track if the key has already spawned
    
    private Color originalColor;  // Store the original color of the tile
    private SpriteRenderer spriteRenderer;


    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        originalColor = spriteRenderer.color;
    }

    private void Update()
    {
        if (playersOnTile >= 1 && otherTile.playersOnTile >= 1 && !keySpawned)
        {
            SpawnKey();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // Check if the object entering the trigger is a gel player or clone
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player on Pressuretile");

            ArrowKeyMovement arrowKeyMovement = other.GetComponent<ArrowKeyMovement>();

            if (arrowKeyMovement != null && PlayerState.IsGel())
            {
                playersOnTile++;
                spriteRenderer.color = pressedColor;
            }
        }else if (other.CompareTag("Boomerang") )
        {
            Boomerang boomerang = other.GetComponent<Boomerang>();
 
            if (boomerang != null && boomerang.isPlayer)
            {
                Debug.Log("Boomerang hit tile!");
                playersOnTile++;
                spriteRenderer.color = pressedColor;
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        // When a gel player or clone leaves the tile, decrease the player count
        if (other.CompareTag("Player"))
        {
            ArrowKeyMovement arrowKeyMovement = other.GetComponent<ArrowKeyMovement>();

            if (arrowKeyMovement != null && PlayerState.IsGel())
            {
                playersOnTile--;

                if (playersOnTile < 1)
                {
                    spriteRenderer.color = originalColor;
                }

                // Reset key spawn if a player leaves and both tiles are not occupied
                if (playersOnTile < 1 || otherTile.playersOnTile < 1)
                {
                    Debug.Log("Both tiles no longer occupied, key won't spawn.");
                }
            }
        }
    }

    private void SpawnKey()
    {
        // Instantiate the key at the specified spawn position
        if (keyPrefab != null && keySpawnPosition != null)
        {
            Instantiate(keyPrefab, keySpawnPosition.position, Quaternion.identity);
            Debug.Log("Key spawned!");
            keySpawned = true;  // Ensure the key only spawns once
        }
    }
}
