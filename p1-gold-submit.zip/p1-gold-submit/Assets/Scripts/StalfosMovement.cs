using System.Collections;
using UnityEngine;

public class StalfosMovement : MonoBehaviour
{
    public float movementSpeed = 2f; // Speed at which the Stalfos moves from one grid point to another
    public SpriteRenderer spriteRenderer;
    public Sprite[] upSprites;
    public Sprite[] downSprites;
    public Sprite[] leftSprites;
    public Sprite[] rightSprites;
    public float animationSpeed = 0.1f;

    public Transform[] patrolPoints; // Patrol points for the Stalfos to move towards
    private int currentPointIndex = 0; // Index of the current patrol point
    private float gridSize = 0.5f; // Size of each grid cell
    private Vector3 targetPosition; // Target position to move towards
    private Vector2 lastDirection; // Last movement direction
    private bool isMoving = false;
    private float timer;
    private int currentSpriteIndex;
    private Rigidbody rb;
    private Coroutine moveCoroutine; // Store a reference to the running coroutine

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb.isKinematic = false;  // Ensure Rigidbody is not kinematic
        rb.constraints = RigidbodyConstraints.FreezeRotation; // Prevent unwanted rotations

        // Set initial target position to the first patrol point
        targetPosition = patrolPoints[currentPointIndex].position;
        StartCoroutine(Patrol());
    }

    void Update()
    {
        // Continue animation if already moving
        if (isMoving)
        {
            UpdateAnimation(lastDirection);
        }
    }

    IEnumerator Patrol()
    {
        while (true) // Infinite loop for continuous patrol
        {
            if (!isMoving)
            {
                // Calculate the direction to the next patrol point
                Vector3 directionToPoint = patrolPoints[currentPointIndex].position - transform.position;
                Vector2 gridDirection = GetGridDirection(directionToPoint);

                // Calculate the next target position based on the grid size
                targetPosition = new Vector3(
                    Mathf.Round(transform.position.x / gridSize) * gridSize + gridDirection.x * gridSize,
                    Mathf.Round(transform.position.y / gridSize) * gridSize + gridDirection.y * gridSize,
                    transform.position.z // Keep z-axis constant for 2D movement
                );
                // Check if the target position is close enough to the patrol point
                if (Vector3.Distance(transform.position, patrolPoints[currentPointIndex].position) <= 1.5f)
                {
                    // Move to the next patrol point
                    currentPointIndex = (currentPointIndex + 1) % patrolPoints.Length;
                }

                // Move to the next grid point if the position is not blocked
                if (!IsPositionBlocked(targetPosition))
                {
                    // Stop any previous movement coroutine before starting a new one
                    if (moveCoroutine != null)
                    {
                        StopCoroutine(moveCoroutine);
                    }

                    moveCoroutine = StartCoroutine(MoveToGridPoint(gridDirection));
                    lastDirection = gridDirection;
                    UpdateAnimation(gridDirection);
                }
                else
                {
                    // If the target position is blocked, try to move to the next patrol point
                    currentPointIndex = (currentPointIndex + 1) % patrolPoints.Length;
                    targetPosition = patrolPoints[currentPointIndex].position;
                }
            }

            yield return null;
        }
    }

    IEnumerator MoveToGridPoint(Vector2 direction)
    {
        isMoving = true;

        // Move towards the target position using Rigidbody velocity
        while (Vector3.Distance(transform.position, targetPosition) > 0.01f) // Use a small threshold to avoid floating-point errors
        {
            rb.MovePosition(Vector3.MoveTowards(transform.position, targetPosition, movementSpeed * Time.deltaTime));
            yield return null;
        }

        rb.MovePosition(targetPosition); // Snap to the exact target position
        isMoving = false;
    }

    Vector2 GetGridDirection(Vector3 direction)
    {
        // Determine grid-based direction based on the direction to the patrol point
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
        {
            return new Vector2(Mathf.Sign(direction.x), 0);
        }
        else
        {
            return new Vector2(0, Mathf.Sign(direction.y));
        }
    }

    bool IsPositionBlocked(Vector3 position)
    {
        // Check for collisions with walls at the target position using a raycast
        RaycastHit hit;
        if (Physics.Raycast(position + Vector3.back * 10, Vector3.forward, out hit, Mathf.Infinity, LayerMask.GetMask("Wall")))
        {
            return hit.collider != null;
        }
        return false;
    }

    void UpdateAnimation(Vector2 direction)
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            currentSpriteIndex = (currentSpriteIndex + 1) % 2; // Switch between sprites

            if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            {
                spriteRenderer.sprite = direction.x > 0 ? rightSprites[currentSpriteIndex] : leftSprites[currentSpriteIndex];
            }
            else
            {
                spriteRenderer.sprite = direction.y > 0 ? upSprites[currentSpriteIndex] : downSprites[currentSpriteIndex];
            }
        }
    }
}
