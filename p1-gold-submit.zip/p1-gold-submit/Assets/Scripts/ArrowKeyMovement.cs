using UnityEngine;
using System.Collections; 

public class ArrowKeyMovement : MonoBehaviour
{
    public float movementSpeed = 8f;
    public SpriteRenderer spriteRenderer;
    public Sprite[] upSprites;
    public Sprite[] downSprites;
    public Sprite[] leftSprites;
    public Sprite[] rightSprites;

    public Sprite[] keeseUpSprites;
    public Sprite[] keeseDownSprites;
    public Sprite[] keeseLeftSprites;
    public Sprite[] keeseRightSprites;

    public Sprite[] originalUpSprites;
    public Sprite[] originalDownSprites;
    public Sprite[] originalLeftSprites;
    public Sprite[] originalRightSprites;
    public Sprite originalSprite; // For the original player sprite

    public float animationSpeed = 0.1f;
    public bool isKnockedBack = false;

    public Sprite[] gelUpSprites;
    public Sprite[] gelDownSprites;
    public Sprite[] gelLeftSprites;
    public Sprite[] gelRightSprites;

    public Sprite[] goriyaUpSprites;
    public Sprite[] goriyaDownSprites;
    public Sprite[] goriyaLeftSprites;
    public Sprite[] goriyaRightSprites;

    public GameObject swordPrefab;
    public GameObject boomerangPrefab;
    public GameObject bowPrefab;
    public GameObject bombPrefab;
    public GameObject wandPrefab;
    private PlayerHealth playerHealth;
    private Inventory inventory;

    private float gridSize = 0.25f;
    private Vector3 targetPosition;
    private Vector2 lastDirection;
    private bool isMoving = false;
    private float timer;
    private int currentSpriteIndex;
    private Rigidbody rb;

    // shapeshifting
    public bool isStalfos = false;
    public bool isKeese = false;
    public bool isGel = false;
    public bool isGoriya = false;

    // Public booleans for enabling/disabling WASD and Arrow Key controls
    public bool enableWASD = true;
    public bool enableArrowKeys = true;

    void Start()
    {
        playerHealth = GetComponent<PlayerHealth>();
        inventory = GetComponent<Inventory>();
        rb = GetComponent<Rigidbody>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb.isKinematic = false;
        rb.constraints = RigidbodyConstraints.FreezeRotation;
        targetPosition = transform.position;

        originalUpSprites = upSprites;
        originalDownSprites = downSprites;
        originalLeftSprites = leftSprites;
        originalRightSprites = rightSprites;
        originalSprite = spriteRenderer.sprite; 

    }

    private void Update()
    {
        if (!isMoving )
        {
            if (Input.GetKeyDown(KeyCode.X))
            {
                Attack();
            }
            else if (Input.GetKeyDown(KeyCode.Z))
            {
                UseAltWeapon();
            }
            else if (Input.GetKeyDown(KeyCode.G))
            {
                UseWand();
            }

            if (Input.GetKeyDown(KeyCode.Space))
            {
                inventory.CycleAlternateWeapon();
            }
        }
    }

    private void FixedUpdate()
    {
        if (!GameController.player_control)
        {
            rb.velocity = Vector2.zero;
            return;
        }

        if (isKnockedBack) return;

        if (!isMoving)
        {
            Vector2 input = GetInput();
            if (input != Vector2.zero)
            {
                targetPosition = new Vector3(
                    Mathf.Round(transform.position.x / gridSize) * gridSize + input.x * gridSize,
                    Mathf.Round(transform.position.y / gridSize) * gridSize + input.y * gridSize,
                    transform.position.z
                );

                if (!IsPositionBlocked(targetPosition))
                {
                    StartCoroutine(MoveToGridPoint(input));
                    lastDirection = input;
                    UpdateAnimation(input);
                }
            }

        }
        else
        {
            UpdateAnimation(lastDirection);
        }
    }

    IEnumerator MoveToGridPoint(Vector2 direction)
    {
        isMoving = true;

        while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
        {
            rb.MovePosition(Vector3.MoveTowards(transform.position, targetPosition, movementSpeed * Time.deltaTime));
            yield return null;
        }

        rb.MovePosition(targetPosition);
        isMoving = false;
    }

    bool IsPositionBlocked(Vector3 position)
    {
        RaycastHit hit;
        if (Physics.Raycast(position + Vector3.back * 10, Vector3.forward, out hit, Mathf.Infinity))
        {
            if (hit.collider.CompareTag("Wall") || hit.collider.CompareTag("WaterTile"))
            {
                return true;
            }
        }
        return false;
    }

    Vector2 GetInput()
    {
        float horizontalInput = 0;
        float verticalInput = 0;

        // WASD input
        if (enableWASD)
        {
            horizontalInput += Input.GetKey(KeyCode.D) ? 1 : Input.GetKey(KeyCode.A) ? -1 : 0;
            verticalInput += Input.GetKey(KeyCode.W) ? 1 : Input.GetKey(KeyCode.S) ? -1 : 0;
        }

        // Arrow Key input
        if (enableArrowKeys)
        {
            horizontalInput += Input.GetKey(KeyCode.RightArrow) ? 1 : Input.GetKey(KeyCode.LeftArrow) ? -1 : 0;
            verticalInput += Input.GetKey(KeyCode.UpArrow) ? 1 : Input.GetKey(KeyCode.DownArrow) ? -1 : 0;
        }

        if (Mathf.Abs(horizontalInput) > 0.0f)
        {
            verticalInput = 0.0f;
        }

        return new Vector2(horizontalInput, verticalInput).normalized;
    }


    void UpdateAnimation(Vector2 direction)
    {
        if (isStalfos)
        {
            UpdateStalfosAnimation(direction); //if stalfos
        }
        else if (isGel)
        {
            UpdateGelAnimation(direction);
        }
        else if (isGoriya)
        {
            UpdateGoriyaAnimation(direction);
        }
        else if (isKeese) //if keese
        {
            transform.localScale = new Vector3(0.5f, 0.5f, 1f);

            timer += Time.deltaTime;
            if (timer >= animationSpeed)
            {
                timer = 0f;
                currentSpriteIndex = (currentSpriteIndex + 1) % 2;

                if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
                {
                    spriteRenderer.sprite = direction.x > 0 ? keeseUpSprites[currentSpriteIndex] : keeseUpSprites[currentSpriteIndex];
                }
                else
                {
                    spriteRenderer.sprite = direction.y > 0 ? keeseUpSprites[currentSpriteIndex] : keeseUpSprites[currentSpriteIndex];
                }
            }
        }
        else
        {
            //reset the right and left sprites to default
            transform.localScale = new Vector3(1f, 1f, 1f);

            spriteRenderer.flipX = false;
            timer += Time.deltaTime;
            if (timer >= animationSpeed)
            {
                timer = 0f;
                currentSpriteIndex = (currentSpriteIndex + 1) % 2;

                if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
                {
                    spriteRenderer.sprite = direction.x > 0 ? rightSprites[currentSpriteIndex] : leftSprites[currentSpriteIndex];
                }
                else
                {
                    spriteRenderer.sprite = direction.y > 0 ? upSprites[currentSpriteIndex] : downSprites[currentSpriteIndex];
                }
            }
        }
    }

    // Stalfos-specific
    void UpdateStalfosAnimation(Vector2 direction)
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            spriteRenderer.flipX = !spriteRenderer.flipX;
        }
    }

    // Gel-specific

    void UpdateGelAnimation(Vector2 direction)
    {

    }

    void UpdateGoriyaAnimation(Vector2 direction)
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            currentSpriteIndex = (currentSpriteIndex + 1) % 2; // Switch between sprites

            if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            {
                spriteRenderer.sprite = direction.x > 0 ?
                    goriyaRightSprites[currentSpriteIndex] : goriyaLeftSprites[currentSpriteIndex];

                if (direction.x < 0)
                {
                    spriteRenderer.flipX = true;
                }
                else if (direction.x > 0)
                {
                    spriteRenderer.flipX = false;
                }
            }
            else
            {
                spriteRenderer.sprite = direction.y > 0 ?
                        goriyaUpSprites[currentSpriteIndex] : goriyaDownSprites[currentSpriteIndex];
                if (direction.y < 0)
                {
                    spriteRenderer.flipX = !spriteRenderer.flipX;
                }
                if (direction.y > 0)
                {
                    spriteRenderer.flipX = !spriteRenderer.flipX;
                }
            }
        }
    }

    void Attack()
    {
        Debug.Log($"isStalfos: {isStalfos}, isGel: {isGel}, isGoriya: {isGoriya}");
        if (isGel)
        {
            return;
        }
        else if (isGoriya)
        {
            UseBoomerang();
            return;
        }
        if (inventory.GetCurrentWeapon() == "Sword")
        {
            GameObject swordInstance = Instantiate(swordPrefab, transform.position, Quaternion.identity, transform);
            Sword swordScript = swordInstance.GetComponent<Sword>();

            if (swordScript != null)
            {
                swordScript.Initialize(playerHealth, lastDirection);
            }
        }
    }

    void UseAltWeapon()
    {
        Debug.Log($"isStalfos: {isStalfos}, isGel: {isGel}, isGoriya: {isGoriya}");
        if (isStalfos || isGel || isKeese)
        {
            Debug.Log("Shapeshifted enemy cannot use alternate weapons.");
            return;
        }

        string alternateWeapon = inventory.GetAlternateWeapon();
        if (alternateWeapon == "Bow" && !isGoriya)
        {
            UseBow();
        }
        else if (alternateWeapon == "Boomerang")
        {
            Debug.Log("UseBoomerang");
            UseBoomerang();
        }
        else if (alternateWeapon == "Bomb" && !isGoriya)
        {
            UseBomb();
        }
    }

    void UseBow()
    {
        GameObject bowInstance = Instantiate(bowPrefab, transform.position, Quaternion.identity, transform);
        Bow bowScript = bowInstance.GetComponent<Bow>();

        if (bowScript != null)
        {
            bowScript.Initialize(lastDirection);
        }
    }

    void UseBoomerang()
    {
        Debug.Log("Entered UseBoomerang");
        if (Boomerang.CanThrowBoomerang())
        {
            Debug.Log("Boomerang throw");
            GameObject boomerangInstance = Instantiate(boomerangPrefab, transform.position, Quaternion.identity);
            Boomerang boomerangScript = boomerangInstance.GetComponent<Boomerang>();

            if (boomerangScript != null)
            {
                boomerangScript.maxDistance = 8f;


                boomerangScript.Initialize(lastDirection);
                
            }
        }
    }

    void UseBomb()
    {
        if (isStalfos || isGel || isGoriya)
        {
            Debug.Log("Stalfos cannot use the Bomb.");
            return;
        }

        if (inventory.GetBombs() > 0)
        {
            Instantiate(bombPrefab, transform.position, Quaternion.identity);
            inventory.UseBomb();
        }
    }

    void UseWand()
    {

        GameObject wandInstance = Instantiate(wandPrefab, transform.position, Quaternion.identity, transform);
        Wand wandScript = wandInstance.GetComponent<Wand>();

        if (wandScript != null)
        {
           wandScript.Initialize(playerHealth, lastDirection);
        }
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Wall") || collision.gameObject.CompareTag("WaterTile") || collision.gameObject.CompareTag("Block"))
        {
            Debug.Log("Collided with wall");
            isMoving = false;
            rb.velocity = Vector3.zero;
            targetPosition = transform.position;
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("Wall") || collision.gameObject.CompareTag("WaterTile") || collision.gameObject.CompareTag("Block"))
        {
            Debug.Log("Collided with wall");
            isMoving = false;
            targetPosition = transform.position;
        }
    }
}
