using System.Collections;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public enum Projectile
    {
        Boomerang
    }

    [Header("Animations")]
    public Sprite[] upSprites;
    public Sprite[] downSprites;
    public Sprite[] leftSprites;
    public Sprite[] rightSprites;
    public bool flipLeftSprite = false;
    public bool flipRightSprite = false;
    public bool flipUpSprite = false;
    public bool flipDownSprite = false;
    public float animationSpeed = 0.1f;
    private SpriteRenderer spriteRenderer;
    public bool oneSprite = false;

    [Header("Movement")]
    public float movementSpeed = 4f; // Speed at which the enemy moves
    public float waitTime = 1f; // Wait time at grid
    public float waitChance = 0.5f; // Percent chance the enemy waits at grid
    public bool canMoveDiagonally = false; // Flag to allow diagonal movement for certain enemies
    public bool waitAtGrid = false; // Flag to signify if enemy waits after moving
    private int moveStepsRemaining; // Number of steps remaining in the current direction
    public int minSteps = 4; // Minimum number of grid cells to move in the same direction
    public int maxSteps = 5; // Maximum number of grid cells to move in the same direction

    [Header("Projectiles")]
    public bool throwsProjectiles = false;
    public Projectile projectile;
    public GameObject boomerangPrefab;

    private float gridSize = 0.5f; // Size of each grid cell
    private Vector3 targetPosition; // Target position to move towards
    private Vector2 lastDirection; // Last movement direction
    private bool isMoving = false;
    private float timer;
    private int currentSpriteIndex;
    private Rigidbody rb;
    private Coroutine moveCoroutine; // Store a reference to the running coroutine

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb.isKinematic = false;  // Ensure Rigidbody is not kinematic
        rb.constraints = RigidbodyConstraints.FreezeRotation; // Prevent unwanted rotations

        // Set initial target position to the enemy's starting position
        targetPosition = transform.position;

        moveStepsRemaining = Random.Range(minSteps, maxSteps+1);
        
        // Start the movement coroutine
        InitializeMovement();
    }

    void OnEnable()
    {
        // This method is called when the GameObject is enabled
        InitializeMovement(); // Ensure the enemy movement is initialized every time the enemy is activated
    }

    public void InitializeMovement()
    {
        Debug.Log("EnemyMovement Start");
        // Set initial target position to the enemy's starting position
        targetPosition = transform.position;
        moveStepsRemaining = Random.Range(minSteps, maxSteps + 1);
        isMoving = false;

        // Start the movement coroutine
        StopAllCoroutines();
        StartCoroutine(MovementRoutine());
    }

    void OnDisable()
    {
        // Stop all coroutines when the enemy is deactivated to ensure they reset properly
        StopAllCoroutines();
    }

    void Update()
    {
        // Continue animation if already moving
        if (isMoving)
        {
            UpdateAnimation(lastDirection);
        }
    }

    public IEnumerator MovementRoutine()
    {
        while (true) // Infinite loop for continuous random movement
        {
            if (!isMoving)
            {
                // Check if the enemy needs to change direction
                if (moveStepsRemaining <= 0)
                {
                    // Determine the random direction to move in
                    lastDirection = GetRandomGridDirection();

                    // Reset the number of steps to move in the new direction
                    moveStepsRemaining = Random.Range(minSteps, maxSteps + 1);
                }

                // Calculate the next target position based on the grid size
                targetPosition = new Vector3(
                    Mathf.Round(transform.position.x / gridSize) * gridSize + lastDirection.x * gridSize,
                    Mathf.Round(transform.position.y / gridSize) * gridSize + lastDirection.y * gridSize,
                    transform.position.z // Keep z-axis constant for 2D movement
                );

                // Move to the next grid point if the position is not blocked
                if (!IsPositionBlocked(targetPosition))
                {
                    // Stop any previous movement coroutine before starting a new one
                    if (moveCoroutine != null)
                    {
                        StopCoroutine(moveCoroutine);
                    }

                    moveCoroutine = StartCoroutine(MoveToGridPoint(lastDirection));
                }
                else
                {
                    // If the target position is blocked, immediately pick a new direction
                    moveStepsRemaining = 0;
                }
            }
            float randValue = Random.value;
            if (waitAtGrid && isMoving && (randValue < waitChance))
            {
                if (throwsProjectiles)
                {
                    switch (projectile)
                    {
                        case Projectile.Boomerang: 
                            UseBoomerang();
                            break;
                    }
                }
                yield return new WaitForSeconds(waitTime); // Wait for a random time before the next move
            }
                
            else
                yield return null;
        }
    }

    IEnumerator MoveToGridPoint(Vector2 direction)
    {
        isMoving = true;

        // Move towards the target position using Rigidbody velocity
        while (Vector3.Distance(transform.position, targetPosition) > 0.01f) // Use a small threshold to avoid floating-point errors
        {
            rb.MovePosition(Vector3.MoveTowards(transform.position, targetPosition, movementSpeed * Time.deltaTime));
            yield return null;
        }

        rb.MovePosition(targetPosition); // Snap to the exact target position
        isMoving = false;

        // Decrement the number of steps remaining in the current direction
        moveStepsRemaining--;
    }

    Vector2 GetRandomGridDirection()
    {
        // Choose a random direction: up, down, left, right (and possibly diagonals)
        int directionIndex = Random.Range(0, canMoveDiagonally ? 8 : 4);
        switch (directionIndex)
        {
            case 0: return new Vector2(1, 0); // Right
            case 1: return new Vector2(-1, 0); // Left
            case 2: return new Vector2(0, 1); // Up
            case 3: return new Vector2(0, -1); // Down
            case 4: return new Vector2(1, 1); // Diagonal Up-Right
            case 5: return new Vector2(-1, 1); // Diagonal Up-Left
            case 6: return new Vector2(1, -1); // Diagonal Down-Right
            case 7: return new Vector2(-1, -1); // Diagonal Down-Left
        }
        return Vector2.zero; // Fallback (should never reach here)
    }

    bool IsPositionBlocked(Vector3 position)
    {
        // Check for collisions with walls at the target position using a raycast
        RaycastHit hit;
        if (Physics.Raycast(position + Vector3.back * 10, Vector3.forward, out hit, Mathf.Infinity, LayerMask.GetMask("Wall")))
        {
            if (hit.collider.CompareTag("InvisibleBlock") || hit.collider.CompareTag("Wall")) return true;

            return hit.collider != null;
        }
        return false;
    }

    void UseBoomerang()
    {

        if (Boomerang.CanThrowBoomerang())
        {
            GameObject boomerangInstance = Instantiate(boomerangPrefab, transform.position, Quaternion.identity);
            Boomerang boomerangScript = boomerangInstance.GetComponent<Boomerang>();
            boomerangScript.holder = gameObject;
            boomerangScript.isPlayer = false;

            if (boomerangScript != null)
            {
                // Initialize the boomerang and set its direction
                boomerangScript.Initialize(lastDirection);
            }
        }
    }

    void UpdateAnimation(Vector2 direction)
    {
        timer += Time.deltaTime;
        if (timer >= animationSpeed)
        {
            timer = 0f;
            if (oneSprite)
            {
                spriteRenderer.flipX = !spriteRenderer.flipX;
            }
            else
            {
                currentSpriteIndex = (currentSpriteIndex + 1) % 2; // Switch between sprites

                if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
                {
                    spriteRenderer.sprite = direction.x > 0 ?
                        rightSprites[currentSpriteIndex] : leftSprites[currentSpriteIndex];
                    if (flipLeftSprite)
                    {  
                        if (direction.x < 0)
                        {
                            spriteRenderer.flipX = true;
                        }
                        else if (direction.x > 0)
                        {
                            spriteRenderer.flipX = false;
                        }
                        
                    }
                    if (flipRightSprite && direction.x > 0)
                    {
                        if (direction.x < 0)
                        {
                            spriteRenderer.flipX = true;
                        }
                        else if (direction.x > 0)
                        {
                            spriteRenderer.flipX = false;
                        }
                    }
                }
                else
                {
                    spriteRenderer.sprite = direction.y > 0 ? 
                        upSprites[currentSpriteIndex] : downSprites[currentSpriteIndex];
                    if (flipDownSprite && direction.y < 0)
                    {
                        spriteRenderer.flipX = !spriteRenderer.flipX;
                    }
                    if (flipUpSprite && direction.y > 0)
                    {
                        spriteRenderer.flipX = !spriteRenderer.flipX;
                    }
                }
            }
            
        }
    }
}
