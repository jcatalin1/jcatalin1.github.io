using System.Collections;
using UnityEngine;

public class Bow : MonoBehaviour
{
    public float attackDuration = 0.3f;
    public GameObject arrowPrefab;
    public int rupeeCostPerArrow = 1;
    public SpriteRenderer spriteRenderer;

    public Vector2 offsetUp = new Vector2(0, 0.5f);
    public Vector2 offsetDown = new Vector2(0, -0.5f);
    public Vector2 offsetLeft = new Vector2(-0.5f, 0);
    public Vector2 offsetRight = new Vector2(0.5f, 0);

    public Sprite upSprite;
    public Sprite downSprite;
    public Sprite leftSprite;
    public Sprite rightSprite;
    private Inventory playerInventory;

    public AudioClip shootSound; // Sound effect for shooting an arrow

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        playerInventory = FindObjectOfType<Inventory>();
        if (playerInventory == null)
        {
            Debug.LogError("Player inventory not found.");
        }
    }

    public void Initialize(Vector2 direction)
    {
        Debug.Log("in initalize");
        Vector2 offset = Vector2.zero;
        if (direction == Vector2.up)
        {
            offset = offsetUp;
            spriteRenderer.sprite = upSprite;
        }
        else if (direction == Vector2.down)
        {
            offset = offsetDown;
            spriteRenderer.sprite = downSprite;
        }
        else if (direction == Vector2.left)
        {
            offset = offsetLeft;
            spriteRenderer.sprite = leftSprite;
        }
        else if (direction == Vector2.right)
        {
            offset = offsetRight;
            spriteRenderer.sprite = rightSprite;
        }
        transform.localPosition = offset;

        // Trigger attack
        Attack(direction);

        StartCoroutine(DestroyAfterTime());
    }

    IEnumerator DestroyAfterTime()
    {
        yield return new WaitForSeconds(attackDuration);
        Destroy(gameObject);
    }

    void Attack(Vector2 direction)
    {
        Inventory playerInventory = FindObjectOfType<Inventory>();
        if (playerInventory != null && playerInventory.rupee_count >= rupeeCostPerArrow)
        {
            playerInventory.rupee_count -= rupeeCostPerArrow;
            ShootArrow(direction);
        }
        else
        {
            Debug.Log("Not enough rupees to shoot an arrow.");
        }
    }

    void ShootArrow(Vector2 direction)
    {
        if (arrowPrefab == null)
        {
            Debug.LogError("Arrow prefab is not assigned!");
            return;
        }

        Debug.Log("Instantiating arrow with direction: " + direction);
        GameObject arrowInstance = Instantiate(arrowPrefab, transform.position, Quaternion.identity);
        Arrow arrowScript = arrowInstance.GetComponent<Arrow>();
        if (arrowScript != null)
        {
            arrowScript.Initialize(direction);
        }
        else
        {
            Debug.LogError("Arrow prefab does not have an Arrow script attached!");
        }

        // Play shoot sound effect
        if (shootSound != null)
        {
            AudioSource.PlayClipAtPoint(shootSound, transform.position);
        }
    }
}
