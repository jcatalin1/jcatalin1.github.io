using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;  // Import to manage scenes

public class GameController : MonoBehaviour
{
    public static bool player_control = true;
    public GameObject player;

    void Start()
    {
        Screen.SetResolution(1024, 960, false);  // Set to windowed mode
    }

    void Update()
    {
        // Detect when the player presses the "4" key (non-numpad)
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            StartCustomLevel();  // Start the custom level when "4" is pressed
        }
    }

    void StartCustomLevel()
    {
        // Load the "TestRoom" scene
        SceneManager.LoadScene("TestRoom");

        if (player)
        {
            ShapeshiftController shapeshiftController = player.GetComponent<ShapeshiftController>();
            if (shapeshiftController) shapeshiftController.RevertToPlayer();
        }
    }
}
