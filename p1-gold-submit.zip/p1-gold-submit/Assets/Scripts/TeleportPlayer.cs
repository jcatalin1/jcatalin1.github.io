using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeleportPlayer : MonoBehaviour
{
    public GameObject player;
    public Transform desiredPos;
    public Vector3 cameraDesiredPos;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.T)) 
        { 
            player.transform.position = desiredPos.position;
            Camera.main.transform.position = cameraDesiredPos;
        }
    }
}
