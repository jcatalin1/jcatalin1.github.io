using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombDrop : MonoBehaviour
{
    public int bombAmount = 1; // add 1 bomb rn 
    public AudioClip pickupSound; 

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Inventory playerInventory = other.GetComponent<Inventory>();

            if (playerInventory != null)
            {
                playerInventory.AddBomb(bombAmount); 
                AudioSource.PlayClipAtPoint(pickupSound, transform.position);
                Destroy(gameObject); 
            }
        }
    }
}
