using UnityEngine;

public class KeeseTransformation : MonoBehaviour
{
    public SpriteRenderer playerSpriteRenderer;
    public Sprite keeseSprite;
    public Inventory playerInventory;
    private ArrowKeyMovement arrowKeyMovement;

    void Start()
    {
        arrowKeyMovement = GetComponent<ArrowKeyMovement>();
    }

    public void TransformToKeese()
    {
        PlayerState.TransformToEnemy(PlayerState.State.Keese);
        transform.localScale = new Vector3(0.5f, 0.5f, 1f);
        playerSpriteRenderer.sprite = keeseSprite;
        arrowKeyMovement.isKeese = true;
        Debug.Log("Player has transformed into keese! (keese transformation.cs)");
    }



    private void KeeseWeapon()
    {
        //playerInventory.PickUpWeapon("Sword");
      
    }
}
