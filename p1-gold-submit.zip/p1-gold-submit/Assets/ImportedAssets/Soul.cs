using UnityEngine;

public class Soul : MonoBehaviour
{
    public EnemyType.Type enemyType; //usually priv but for testing teehee

    public void SetEnemyType(EnemyType.Type type)
    {
        enemyType = type;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && other.gameObject.name == "Player")
        {
            ShapeshiftController shapeshiftController = other.GetComponent<ShapeshiftController>();
            if (shapeshiftController != null)
            {
                shapeshiftController.CollectSoul(enemyType);
            }
            Destroy(gameObject); // Destroy the soul after collection
        }
    }
}
