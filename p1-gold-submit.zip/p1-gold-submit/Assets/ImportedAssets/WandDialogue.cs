using UnityEngine;
using System.Collections;

public class WandPickup : MonoBehaviour
{
    public bool collectedWand = false; // Start with the wand uncollected
    public GameObject dialoguePanel;    // UI panel to display the dialogue
    public GameObject keyDoorTrigger;   // Reference to the key door trigger to unlock
    public AudioClip collectSound;       // Sound to play when collecting the wand
    public AudioClip unlockSound;        // Sound to play when unlocking the weapon
    private AudioSource audioSource;     // Reference to AudioSource component

    void Start()
    {
        dialoguePanel.SetActive(false); // Hide dialogue panel at start
        audioSource = GetComponent<AudioSource>(); // Get the AudioSource component
    }

    void CollectWand()
    {
        collectedWand = true;
        PlayCollectSound();
        StartCoroutine(ShowDialogue());
        UnlockKeyDoorTrigger();
        // Remove the line that disables the GameObject here
    }

    // Play the wand collect sound
    void PlayCollectSound()
    {
        if (audioSource && collectSound)
        {
            audioSource.PlayOneShot(collectSound);
        }

        if (audioSource && unlockSound)
        {
            audioSource.PlayOneShot(unlockSound);
        }
    }

    IEnumerator ShowDialogue()
    {
        dialoguePanel.SetActive(true);

        yield return new WaitForSeconds(3f);

        dialoguePanel.SetActive(false);

        // Disable the WandPickup GameObject after showing the dialogue
        gameObject.SetActive(false);
    }

    void UnlockKeyDoorTrigger()
    {
        KeyDoor keyDoor = keyDoorTrigger.GetComponent<KeyDoor>();
        if (keyDoor != null)
        {
            keyDoor.Unlock();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !collectedWand)
        {
            CollectWand();
        }
    }
}
