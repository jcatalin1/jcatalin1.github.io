using UnityEngine;
using UnityEngine.UI; 
using System.Collections;

public class DialogueTrigger : MonoBehaviour
{
    public GameObject dialoguePanel; 
    public Text dialogueText;
    public string dialogue;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) 
        {
            Debug.Log("triggered");
            StartCoroutine(ShowDialogue());
        }
    }

    private IEnumerator ShowDialogue()
    {

        dialoguePanel.SetActive(true);
        dialogueText.text = dialogue;

        yield return new WaitForSeconds(3f);

        dialoguePanel.SetActive(false);
    }
}
