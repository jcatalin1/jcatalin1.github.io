using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStateDisplayer : MonoBehaviour
{
    public Image stateImage; // Image component to display the current state
    public Sprite playerSprite; // Sprite for Player state
    public Sprite keeseSprite; // Sprite for Keese state
    public Sprite stalfosSprite; // Sprite for Stalfos state
    public Sprite aquamentusSprite; // Sprite for Aquamentus state
    public Sprite gelSprite; // Sprite for Gel state
    public Sprite goriyaSprite; // Sprite for Goriya state
    public Text stateText; // Text component to display the current state name

    // Update is called once per frame
    void Update()
    {
        // Update the text and image based on the current player state
        UpdatePlayerStateDisplay();
    }

    void UpdatePlayerStateDisplay()
    {
        // Check the current player state and update the image and text
        if (PlayerState.IsPlayer())
        {
            stateImage.sprite = playerSprite;
            stateText.text = "Player";
        }
        else if (PlayerState.IsKeese())
        {
            stateImage.sprite = keeseSprite;
            stateText.text = "Keese";
        }
        else if (PlayerState.IsStalfos())
        {
            stateImage.sprite = stalfosSprite;
            stateText.text = "Stalfos";
        }
        else if (PlayerState.IsAquamentus())
        {
            stateImage.sprite = aquamentusSprite;
            stateText.text = "Aquamentus";
        }
        else if (PlayerState.IsGel())
        {
            stateImage.sprite = gelSprite;
            stateText.text = "Gel";
        }
        else if (PlayerState.IsGoriya())
        {
            stateImage.sprite = goriyaSprite;
            stateText.text = "Goriya";
        }
    }
}
