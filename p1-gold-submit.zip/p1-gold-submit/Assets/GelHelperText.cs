using UnityEngine;
using UnityEngine.UI;  // Required for UI elements

public class GelHelperText : MonoBehaviour
{
    public Text statusText;   // Reference to the UI Text element in the scene
    public string gelStateText = "Control Gels with WASD / Arrow Keys"; // The text to display when in Gel form

    void Start()
    {
        // Initially hide the status text
        if (statusText != null)
        {
            statusText.gameObject.SetActive(false);
        }
    }

    void Update()
    {
        // Check the player's state and update the UI
        UpdatePlayerState();
    }

    // Update the text based on whether the player is in Gel form
    void UpdatePlayerState()
    {
        if (PlayerState.IsGel())
        {
            // Show the status text if the player is in Gel state
            if (statusText != null)
            {
                statusText.gameObject.SetActive(true);
                statusText.text = gelStateText;
            }
        }
        else
        {
            // Hide the status text if the player is not in Gel state
            if (statusText != null)
            {
                statusText.gameObject.SetActive(false);
            }
        }
    }
}
